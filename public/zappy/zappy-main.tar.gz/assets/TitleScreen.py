import asyncio
import pygame
from config import SCREEN_WIDTH, SCREEN_HEIGHT, FPS


class TitleScreen:
    def __init__(self, screen, clock):
        self.screen = screen
        self.clock = clock
        self.active = True

        # Fonts
        self.title_font = pygame.font.SysFont(None, 72)
        self.prompt_font = pygame.font.SysFont(None, 36)

        # Text
        self.title_text = self.title_font.render("ZAPPY", True, (255, 0, 0))
        self.prompt_text = self.prompt_font.render("Press any key to start", True, (255, 255, 255))

    async def run(self):
        """Loop for the title screen"""
        while self.active:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.active = False
                    return False
                elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                    self.active = False
                    return True

            # Background
            self.screen.fill((0, 0, 0))

            # Centered text
            self.screen.blit(
                self.title_text,
                self.title_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
            )
            self.screen.blit(
                self.prompt_text,
                self.prompt_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))
            )

            pygame.display.flip()
            self.clock.tick(FPS)
            await asyncio.sleep(0)
