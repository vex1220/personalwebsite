#Screen settings
SCREEN_WIDTH = 800
SCREEN_HEIGHT= 600
FPS = 60

# Default level dimensions (can be overriden)
DEFAULT_LEVEL_WIDTH = SCREEN_WIDTH * 4
DEFAULT_LEVEL_HEIGHT = SCREEN_HEIGHT

#Player settings
PLAYER_SPEED = 5
JUMP_STRENGTH = 15
GRAVITY = 0.8

# Colors
SKY_BLUE = (135, 206, 235)
DARK_GRAY = (20, 20, 30)
RED = (255, 0, 0)

#Game Settings
SHOW_ENEMY_HEALTH = False

# Scoring for boss fights
SCORE_START = 10000
# Linear decay rate (points per second)
SCORE_DECAY_RATE = 500
# Minimum score floor (prevents score reaching zero)
SCORE_MIN = 100

# Top-down movement (NO GRAVITY in top-down!)
PLAYER_TOP_DOWN_SPEED = 200  # pixels per second
PLAYER_DIAGONAL_MULTIPLIER = 0.707  # sqrt(2)/2 for normalized diagonal movement

# Wave System
WAVE_ENEMY_MULTIPLIER = 1.5  # Each wave spawns 50% more enemies
WAVE_BREAK_DURATION = 3.0    # Seconds between waves
MAX_WAVES = 5

# Level 2 Enemies
BASIC_ENEMY_SPEED = 100
BASIC_ENEMY_HEALTH = 50
FAST_ENEMY_SPEED = 180
FAST_ENEMY_HEALTH = 30
TANK_ENEMY_SPEED = 60
TANK_ENEMY_HEALTH = 150

# Level 2 Weapons
STARTING_WEAPON_DAMAGE = 25
STARTING_WEAPON_COOLDOWN = 0.3  # seconds between shots

# --- DOODLE JUMP TUNABLES ---
DJ_SCREEN_WIDTH  = 400
DJ_SCREEN_HEIGHT = 600
DJ_FPS = 60

DJ_GRAVITY = 0.35
DJ_JUMP_STRENGTH = 11
DJ_PLAYER_SPEED = 4

DJ_PLATFORM_COUNT = 10
DJ_SCROLL_TRIGGER_Y = DJ_SCREEN_HEIGHT // 3

DJ_SPRITE_PATH = "assets/images/zappy_walk.png"
# Optional hints (leave as None to auto-detect)
DJ_SPRITE_COLS = None   # e.g., 4 for the wide sheet, 3 for grid
DJ_SPRITE_ROWS = None   # e.g., 1 for wide strip, 2 for grid
DJ_SPRITE_ROW_TO_USE = None  # For multi-row sheets: None = use all rows, or pick 0/1
