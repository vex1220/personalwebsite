import pygame
import config
from src.entities.player import Player
from src.levels.forest_survival import ForestSurvival
from src.entities.base_weapon import BaseWeapon
from src.entities.common.basic_projectile import BasicProjectile

# Import enemy types
from src.entities.common.forest_enemies import (
    BasicChaser, FastFlanker, TankBrute, RangedShooter, ExploderEnemy
)


# Test weapon class - properly inherits from BaseWeapon
class TestWeapon(BaseWeapon):
    """Simple test weapon that shoots yellow bullets"""
    
    def __init__(self, x, y):
        super().__init__(x, y, name="Test Gun")
        
        # Weapon properties
        self.damage = 25
        self.fire_rate = 0.15  # Fast shooting
        self.projectile_speed = 300  # Fast bullets
        self.ammo = -1  # Infinite ammo
        
        # Visual
        self.image = pygame.Surface((15, 8))
        self.image.fill((150, 150, 150))  # Gray gun
        self.rect = self.image.get_rect()
    
    def update_position(self):
        """Position weapon next to player"""
        if self.owner:
            self.rect.centerx = self.owner.rect.right + 5
            self.rect.centery = self.owner.rect.centery
    
    def create_projectile(self, target_pos=None):
        """Create a simple bullet"""
        if target_pos is None:
            target_pos = (self.rect.centerx + 100, self.rect.centery)
        
        # Create bullet at weapon position
        projectile = BasicProjectile(
            self.rect.centerx,
            self.rect.centery,
            target_pos[0],
            target_pos[1],
            speed=self.projectile_speed,
            damage=self.damage
        )
        
        projectile.set_owner(self.owner)
        return projectile


# Initialize pygame
pygame.init()
screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
pygame.display.set_caption("Zappy - Enemy Combat Test")
clock = pygame.time.Clock()

# Create player with health
class TestPlayer(Player):
    """Extended player with health for testing"""
    def __init__(self, x, y):
        super().__init__(x, y)
        self.health = 100
        self.max_health = 100
        self.invincible = False

# Create player
player = TestPlayer(100, 100)

# Create and enter level
current_level = ForestSurvival(player)

# Add enemy_projectiles group if it doesn't exist
if not hasattr(current_level, 'enemy_projectiles'):
    current_level.enemy_projectiles = pygame.sprite.Group()

current_level.on_enter()

# Give player a test weapon
test_weapon = TestWeapon(0, 0)
player.equip_weapon(test_weapon)

# Test mode settings
test_mode = "manual"  # Start in manual mode for testing
spawn_timer = 0

# Manual enemy spawning
def spawn_test_enemy(enemy_type, level):
    """Spawn an enemy near the player for testing"""
    import random
    
    # Spawn around player at medium distance
    angle = random.uniform(0, 2 * 3.14159)
    distance = random.randint(200, 400)
    
    x = level.player.rect.centerx + int(distance * pygame.math.Vector2(1, 0).rotate_rad(angle).x)
    y = level.player.rect.centery + int(distance * pygame.math.Vector2(1, 0).rotate_rad(angle).y)
    
    # Keep in bounds
    x = max(50, min(x, level.level_width - 50))
    y = max(50, min(y, level.level_height - 50))
    
    # Create enemy
    enemy = enemy_type(x, y)
    enemy.set_level(level)
    level.enemies.add(enemy)
    
    return enemy

# Collision detection function
def handle_collisions():
    """Handle all collision detection"""
    # Player projectiles hit enemies
    hits = pygame.sprite.groupcollide(
        current_level.projectiles,
        current_level.enemies,
        True,  # Remove projectile
        False  # Don't remove enemy yet
    )
    
    for projectile, enemy_list in hits.items():
        for enemy in enemy_list:
            damage = projectile.damage if hasattr(projectile, 'damage') else 10
            died = enemy.take_damage(damage)
            if died:
                print(f"💀 {enemy.__class__.__name__} destroyed!")
    
    # Enemy projectiles hit player
    if hasattr(current_level, 'enemy_projectiles'):
        player_hit = pygame.sprite.spritecollide(
            player,
            current_level.enemy_projectiles,
            True  # Remove projectile
        )
        
        for projectile in player_hit:
            if not player.invincible:
                damage = projectile.damage if hasattr(projectile, 'damage') else 10
                player.health = max(0, player.health - damage)
                print(f"💥 Player hit! Health: {player.health}/{player.max_health}")
    
    # Enemies collide with player (melee)
    enemy_collisions = pygame.sprite.spritecollide(
        player,
        current_level.enemies,
        False
    )
    
    for enemy in enemy_collisions:
        if enemy.can_attack() and not player.invincible:
            damage = enemy.attack()
            player.health = max(0, player.health - damage)
            print(f"⚔️ Melee hit from {enemy.__class__.__name__}! Damage: {damage}, Health: {player.health}")

print("=" * 70)
print("ENEMY COMBAT TEST")
print("=" * 70)
print("CONTROLS:")
print("  WASD - Move")
print("  Arrow Keys - Shoot")
print("  1-5 - Spawn enemy type")
print("  I - Toggle invincibility")
print("  C - Clear all enemies")
print("  ESC - Quit")
print()
print("ENEMY TYPES:")
print("  1 = Basic Chaser (red, 50 HP)")
print("  2 = Fast Flanker (orange, 30 HP)")
print("  3 = Tank Brute (dark red, 200 HP)")
print("  4 = Ranged Shooter (blue, 40 HP)")
print("  5 = Exploder (yellow, 25 HP)")
print("=" * 70)

# Game loop
running = True
show_instructions = True

# Spawn a few enemies to start
for i in range(3):
    spawn_test_enemy(BasicChaser, current_level)
print(f"Spawned 3 Basic Chasers to start!")

while running:
    dt = clock.tick(config.FPS) / 1000.0
    
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
            
            # Toggle invincibility
            elif event.key == pygame.K_i:
                player.invincible = not player.invincible
                print(f"🛡️ Invincibility: {'ON' if player.invincible else 'OFF'}")
            
            # Clear enemies
            elif event.key == pygame.K_c:
                count = len(current_level.enemies)
                current_level.enemies.empty()
                print(f"🧹 Cleared {count} enemies")
            
            # Toggle instructions
            elif event.key == pygame.K_h:
                show_instructions = not show_instructions
            
            # Spawn specific enemy types
            elif event.key == pygame.K_1:
                enemy = spawn_test_enemy(BasicChaser, current_level)
                print(f"Spawned BasicChaser at {enemy.rect.center}")
            elif event.key == pygame.K_2:
                enemy = spawn_test_enemy(FastFlanker, current_level)
                print(f"Spawned FastFlanker at {enemy.rect.center}")
            elif event.key == pygame.K_3:
                enemy = spawn_test_enemy(TankBrute, current_level)
                print(f"Spawned TankBrute at {enemy.rect.center}")
            elif event.key == pygame.K_4:
                enemy = spawn_test_enemy(RangedShooter, current_level)
                print(f"Spawned RangedShooter at {enemy.rect.center}")
            elif event.key == pygame.K_5:
                enemy = spawn_test_enemy(ExploderEnemy, current_level)
                print(f"Spawned ExploderEnemy at {enemy.rect.center}")
    
    # Update level
    current_level.handle_events(events)
    current_level.update(dt)
    
    # Update enemy projectiles if they exist
    if hasattr(current_level, 'enemy_projectiles'):
        current_level.enemy_projectiles.update(dt)
    
    # Handle collisions
    handle_collisions()
    
    # Check game over
    if player.health <= 0 and not player.invincible:
        print("💀 GAME OVER!")
    
    # Draw everything
    current_level.draw(screen, None)
    
    # Draw enemy projectiles if they exist
    if hasattr(current_level, 'enemy_projectiles'):
        for projectile in current_level.enemy_projectiles:
            draw_rect = projectile.rect.copy()
            draw_rect.x -= current_level.camera_x
            draw_rect.y -= current_level.camera_y
            screen.blit(projectile.image, draw_rect)
    
    # Draw HUD
    font = pygame.font.Font(None, 36)
    small_font = pygame.font.Font(None, 24)
    
    # Stats box background
    stats_bg = pygame.Rect(5, 5, 250, 150)
    pygame.draw.rect(screen, (0, 0, 0, 200), stats_bg)
    pygame.draw.rect(screen, (255, 255, 255), stats_bg, 2)
    
    # FPS
    fps = int(clock.get_fps())
    fps_text = small_font.render(f"FPS: {fps}", True, (255, 255, 255))
    screen.blit(fps_text, (10, 10))
    
    # Enemy count
    enemy_count = len(current_level.enemies)
    enemy_color = (255, 0, 0) if enemy_count > 0 else (100, 100, 100)
    enemy_text = small_font.render(f"Enemies: {enemy_count}", True, enemy_color)
    screen.blit(enemy_text, (10, 35))
    
    # Projectile counts
    player_bullets = len(current_level.projectiles)
    bullet_text = small_font.render(f"Your Bullets: {player_bullets}", True, (255, 255, 0))
    screen.blit(bullet_text, (10, 60))
    
    if hasattr(current_level, 'enemy_projectiles'):
        enemy_bullets = len(current_level.enemy_projectiles)
        enemy_bullet_text = small_font.render(f"Enemy Bullets: {enemy_bullets}", True, (255, 100, 0))
        screen.blit(enemy_bullet_text, (10, 85))
    
    # Health bar
    health_bar_width = 230
    health_bar_height = 20
    health_percentage = player.health / player.max_health
    
    # Background
    health_bg = pygame.Rect(10, 120, health_bar_width, health_bar_height)
    pygame.draw.rect(screen, (100, 0, 0), health_bg)
    
    # Health fill
    health_fill_width = int(health_bar_width * health_percentage)
    health_fill = pygame.Rect(10, 120, health_fill_width, health_bar_height)
    
    # Color based on health
    if health_percentage > 0.6:
        health_color = (0, 255, 0)
    elif health_percentage > 0.3:
        health_color = (255, 255, 0)
    else:
        health_color = (255, 0, 0)
    
    pygame.draw.rect(screen, health_color, health_fill)
    pygame.draw.rect(screen, (255, 255, 255), health_bg, 2)
    
    # Health text
    health_text = small_font.render(f"HP: {int(player.health)}/{int(player.max_health)}", True, (255, 255, 255))
    screen.blit(health_text, (15, 122))
    
    # Invincibility indicator
    if player.invincible:
        invincible_bg = pygame.Rect(260, 5, 150, 30)
        pygame.draw.rect(screen, (255, 215, 0), invincible_bg)
        pygame.draw.rect(screen, (255, 255, 255), invincible_bg, 2)
        invincible_text = font.render("INVINCIBLE", True, (0, 0, 0))
        screen.blit(invincible_text, (265, 8))
    
    # Instructions
    if show_instructions:
        inst_bg = pygame.Rect(5, config.SCREEN_HEIGHT - 220, 280, 215)
        pygame.draw.rect(screen, (0, 0, 0, 220), inst_bg)
        pygame.draw.rect(screen, (255, 255, 255), inst_bg, 2)
        
        instructions = [
            "=== CONTROLS ===",
            "WASD: Move",
            "Arrows: Shoot",
            "1-5: Spawn Enemy",
            "I: Invincibility",
            "C: Clear Enemies",
            "H: Hide Help",
            "ESC: Quit"
        ]
        
        for i, text in enumerate(instructions):
            color = (255, 215, 0) if text.startswith("===") else (200, 200, 200)
            inst_text = small_font.render(text, True, color)
            screen.blit(inst_text, (10, config.SCREEN_HEIGHT - 215 + i * 25))
    else:
        help_bg = pygame.Rect(5, config.SCREEN_HEIGHT - 35, 180, 30)
        pygame.draw.rect(screen, (0, 0, 0, 200), help_bg)
        pygame.draw.rect(screen, (255, 255, 255), help_bg, 2)
        help_text = small_font.render("Press H for help", True, (200, 200, 200))
        screen.blit(help_text, (10, config.SCREEN_HEIGHT - 32))
    
    # Enemy type legend
    legend_bg = pygame.Rect(config.SCREEN_WIDTH - 235, 5, 230, 155)
    pygame.draw.rect(screen, (0, 0, 0, 200), legend_bg)
    pygame.draw.rect(screen, (255, 255, 255), legend_bg, 2)
    
    legend_font = pygame.font.Font(None, 20)
    legend_title = small_font.render("ENEMY TYPES:", True, (255, 215, 0))
    screen.blit(legend_title, (config.SCREEN_WIDTH - 230, 10))
    
    legend_items = [
        ("1: Chaser", (200, 50, 50)),
        ("2: Flanker", (255, 150, 0)),
        ("3: Tank", (100, 20, 20)),
        ("4: Shooter", (50, 100, 200)),
        ("5: Exploder", (255, 200, 0))
    ]
    
    for i, (text, color) in enumerate(legend_items):
        # Color square
        color_rect = pygame.Rect(config.SCREEN_WIDTH - 225, 35 + i * 24, 20, 20)
        pygame.draw.rect(screen, color, color_rect)
        pygame.draw.rect(screen, (255, 255, 255), color_rect, 1)
        
        # Text
        legend_text = legend_font.render(text, True, (200, 200, 200))
        screen.blit(legend_text, (config.SCREEN_WIDTH - 200, 38 + i * 24))
    
    # Game over overlay
    if player.health <= 0 and not player.invincible:
        overlay = pygame.Surface((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))
        
        game_over_font = pygame.font.Font(None, 72)
        game_over_text = game_over_font.render("GAME OVER", True, (255, 0, 0))
        game_over_rect = game_over_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 - 50))
        screen.blit(game_over_text, game_over_rect)
        
        restart_text = font.render("Press R to restart", True, (255, 255, 255))
        restart_rect = restart_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 + 20))
        screen.blit(restart_text, restart_rect)
        
        # Handle restart
        keys = pygame.key.get_pressed()
        if keys[pygame.K_r]:
            player.health = player.max_health
            current_level.enemies.empty()
            if hasattr(current_level, 'enemy_projectiles'):
                current_level.enemy_projectiles.empty()
            current_level.projectiles.empty()
            print("🔄 Game restarted!")
    
    pygame.display.flip()

pygame.quit()
print("\n=== Test Session Ended ===")
print(f"Final enemy count: {len(current_level.enemies)}")
print(f"Final player health: {player.health}")