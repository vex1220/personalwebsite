import asyncio
import pygame
import random
import os

# --- Config ---
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
FPS = 60
GRAVITY = 0.5
JUMP_STRENGTH = -10
PIPE_SPEED = 3
PIPE_GAP = 150


# --- Player ---
class Player:
    def __init__(self):
        self.x = 100
        self.y = SCREEN_HEIGHT // 3  # start higher on the screen
        self.velocity = 0
        self.radius = 20
        # Load player image
        try:
            img_path = os.path.join(os.path.dirname(__file__), "flappybird_images", "flappyzappy.png")
            self.image = pygame.image.load(img_path).convert_alpha()
            self.image = pygame.transform.scale(self.image, (self.radius * 2.5, self.radius * 2.5))
            self.image = pygame.transform.flip(self.image, True, False)  # Flip horizontally to face right
        except pygame.error:
            # Fallback to circle if image not found
            self.image = None

    def update(self):
        self.velocity += GRAVITY
        self.y += self.velocity
        if self.y > SCREEN_HEIGHT - self.radius:
            self.y = SCREEN_HEIGHT - self.radius
            self.velocity = 0

    def jump(self):
        self.velocity = JUMP_STRENGTH

    def draw(self, surface):
        if self.image:
            surface.blit(self.image, (int(self.x - self.radius), int(self.y - self.radius)))
        else:
            pygame.draw.circle(surface, (255, 255, 0), (int(self.x), int(self.y)), self.radius)

# --- Pipe ---
class Pipe:
    def __init__(self):
        self.x = SCREEN_WIDTH
        self.height = random.randint(100, SCREEN_HEIGHT - 200)
        self.passed = False

    def update(self):
        self.x -= PIPE_SPEED

    def draw(self, surface):
        # Top pipe
        pygame.draw.rect(surface, (0, 255, 0), (self.x, 0, 50, self.height))
        # Bottom pipe
        pygame.draw.rect(surface, (0, 255, 0), (self.x, self.height + PIPE_GAP, 50, SCREEN_HEIGHT))

    def collide(self, player):
        if player.x + player.radius > self.x and player.x - player.radius < self.x + 50:
            if player.y - player.radius < self.height or player.y + player.radius > self.height + PIPE_GAP:
                return True
        return False

# --- Game Loop ---
async def main(standalone=True):
    # Initialize pygame and create window inside main function
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Flappy Zappy")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 48)

    # Load background image with proper path
    try:
        bg_path = os.path.join(os.path.dirname(__file__), "flappybird_images", "FB_background.png")
        background_img = pygame.image.load(bg_path).convert()
        background_img = pygame.transform.scale(background_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
    except pygame.error:
        # Fallback if image not found
        background_img = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        background_img.fill((135, 206, 235))  # Sky blue

    player = Player()
    pipes = []
    spawn_timer = 0
    score = 0
    running = True
    game_started = False  # Wait until the player presses space

    while running:
        clock.tick(FPS)
        screen.blit(background_img, (0, 0))


        # --- Events ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False  # ESC to return to menu
                elif event.key == pygame.K_SPACE:
                    if not game_started:
                        game_started = True  # Start the game on first press
                    player.jump()

        # --- Update ---
        if game_started:
            player.update()

            spawn_timer += 1
            if spawn_timer > 90:  # spawn new pipe every 1.5 seconds
                pipes.append(Pipe())
                spawn_timer = 0

            for pipe in pipes:
                pipe.update()
                if not pipe.passed and pipe.x + 50 < player.x:
                    pipe.passed = True
                    score += 1

            # Remove pipes that are off-screen
            pipes = [pipe for pipe in pipes if pipe.x + 50 > 0]

            # --- Check Collisions ---
            for pipe in pipes:
                if pipe.collide(player):
                    running = False
            if player.y >= SCREEN_HEIGHT - player.radius:
                running = False

        # --- Draw ---
        player.draw(screen)
        for pipe in pipes:
            pipe.draw(screen)

        # Draw score
        score_text = font.render(str(score), True, (255, 0, 0))
        screen.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 20))

        # Draw start message
        if not game_started:
            msg = font.render("Press SPACE", True, (255, 255, 255))
            screen.blit(msg, (SCREEN_WIDTH // 2 - msg.get_width() // 2, SCREEN_HEIGHT // 2))

        pygame.display.flip()
        await asyncio.sleep(0)

    # Only quit pygame if running standalone, not from menu
    if standalone:
        pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())
