import asyncio
import pygame
import sys
import config

# Lazy imports inside launchers avoid initializing subsystems twice

async def launch_forest_survival(screen, clock):
    from src.entities.player import Player
    from src.levels.forest_survival import ForestSurvival
    player = Player(screen.get_width() / 2, screen.get_height() / 2)
    level = ForestSurvival(player)
    level.on_enter()
    running = True
    while running:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False  # exit whole app
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False  # back to menu
        level.update(dt)
        level.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)
    return True  # return to menu

async def launch_boss_level(screen, clock):
    from src.levels.boss_level.level import BossLevel
    level = BossLevel()  # BossLevel creates its own Player if missing
    level.on_enter()
    running = True
    while running:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
            # Forward individual events when level expects them
            try:
                if hasattr(level, 'handle_events'):
                    level.handle_events(event)
            except Exception:
                pass
        # Check if level requested a restart or exit-to-menu
        try:
            if getattr(level, '_exit_requested', False):
                running = False
                break
            if getattr(level, '_restart_requested', False):
                # Recreate the level fresh
                level = BossLevel()
                level.on_enter()
                continue
        except Exception:
            pass
        level.update(dt)
        level.draw(screen)
        pygame.display.flip()
        await asyncio.sleep(0)
    return True

async def launch_doodle_jump(screen, clock):
    # Doodle Jump uses different resolution; run its loop without pygame.quit()
    from src.levels.doodle_jump.run import main as doodle_main
    await doodle_main(standalone=False)  # Don't quit pygame when returning
    # Reinitialize pygame base window for returning to menu
    pygame.init()
    pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
    pygame.display.set_caption("Zappy - Level Select")
    return True

async def launch_flappybird(screen, clock):
    from src.levels.Flappybird.flappybird import main as flappy_main
    await flappy_main(standalone=False)  # Don't quit pygame when returning
    pygame.init()
    pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
    pygame.display.set_caption("Zappy - Level Select")
    return True

MENU_OPTIONS = [
    ("Forest Survival", launch_forest_survival),
    ("Boss Arena", launch_boss_level),
    ("Doodle Jump", launch_doodle_jump),
    ("Flappy Zappy", launch_flappybird),
    ("Quit", None),
]

TITLE_COLOR = (255, 200, 40)
OPTION_COLOR = (240, 240, 240)
HIGHLIGHT_COLOR = (80, 160, 255)
BG_COLOR = (25, 25, 35)


async def run_level_menu(screen, clock):
    pygame.font.init()
    title_font = pygame.font.SysFont(None, 64)
    option_font = pygame.font.SysFont(None, 40)

    selected = 0
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_q):
                    return False
                if event.key in (pygame.K_DOWN, pygame.K_s):
                    selected = (selected + 1) % len(MENU_OPTIONS)
                if event.key in (pygame.K_UP, pygame.K_w):
                    selected = (selected - 1) % len(MENU_OPTIONS)
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    label, fn = MENU_OPTIONS[selected]
                    if fn is None:  # Quit
                        return False
                    # Launch chosen level; if level returns False, exit app entirely
                    result = await fn(screen, clock)
                    if not result:
                        return False
                    # After returning from level, refresh screen reference and ensure proper state
                    screen = pygame.display.get_surface()
                    if screen is None:
                        screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
                    pygame.display.set_caption("Zappy - Level Select")

        # Draw menu
        screen.fill(BG_COLOR)
        title_surf = title_font.render("Select Level", True, TITLE_COLOR)
        screen.blit(title_surf, title_surf.get_rect(center=(config.SCREEN_WIDTH // 2, 100)))

        start_y = 200
        line_height = 55
        for idx, (label, _) in enumerate(MENU_OPTIONS):
            color = HIGHLIGHT_COLOR if idx == selected else OPTION_COLOR
            surf = option_font.render(label, True, color)
            screen.blit(surf, surf.get_rect(center=(config.SCREEN_WIDTH // 2, start_y + idx * line_height)))

        instr_font = pygame.font.SysFont(None, 24)
        instructions = ["UP/DOWN or W/S to move", "ENTER/SPACE to select", "ESC/Q to quit or back", "ESC works in ALL levels to return here"]
        for i, text in enumerate(instructions):
            s = instr_font.render(text, True, (160, 160, 170))
            screen.blit(s, (20, config.SCREEN_HEIGHT - 120 + i * 22))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    return False

__all__ = ["run_level_menu"]
