import pygame
import random
import math
import config
from src.levels.base_level import BaseLevel
from src.entities.common.forest_enemies import (
    BasicChaser, FastFlanker, TankBrute, RangedShooter, ExploderEnemy
)

class ForestSurvival(BaseLevel):
    def __init__(self, player):
        # Create a basic square map (2x screen size)
        super().__init__(player, 
                        level_width=config.SCREEN_WIDTH * 2, 
                        level_height=config.SCREEN_HEIGHT * 2)
        
        self.bg_color = (50, 100, 50)  # Green for top-down
        
        # Camera offset for scrolling
        self.camera_x = 0
        self.camera_y = 0
        
        # Enemy spawning system
        self.spawn_timer = 0.0
        self.spawn_interval = 2.5  # Faster base spawn rate
        self.max_enemies = 25  # More enemies allowed on screen
        self.difficulty_timer = 0.0  # Tracks time for difficulty scaling
        self.wave_number = 1
        
        # Enemy spawn weights (higher = more common) - Made special enemies more frequent
        # Format: {enemy_class: (weight, min_difficulty_time)}
        self.enemy_spawn_table = {
            BasicChaser: (80, 0),       # Reduced weight to make room for specials
            FastFlanker: (70, 20),      # Earlier unlock, higher weight
            RangedShooter: (50, 40),    # Much earlier unlock, higher weight  
            ExploderEnemy: (35, 60),    # Earlier unlock, much higher weight
            TankBrute: (20, 90),        # Earlier unlock, higher weight
        }
        
        # Multi-spawn system
        self.min_spawn_count = 1
        self.max_spawn_count = 3  # Can spawn up to 3 enemies at once
        
        # Enemy projectiles group (for ranged enemies)
        self.enemy_projectiles = pygame.sprite.Group()
        
        # Game over state
        self.game_over = False
        self.game_over_timer = 0.0
        self.final_time = 0
        self.enemies_defeated = 0
    
    def spawn_projectile(self, projectile):
        """
        Add projectile to level's projectile group.
        CRITICAL METHOD - Called by player.fire_weapon()
        """
        if projectile:
            projectile.set_level(self)
            self.projectiles.add(projectile)
            print(f"Projectile spawned at {projectile.rect.center}")  # Debug
    
    def on_enter(self):
        """Called when level starts"""
        super().on_enter()  # Sets player level reference
        
        # Reset player position to center of map
        self.player.rect.centerx = self.level_width // 2
        self.player.rect.centery = self.level_height // 2
        
        # Reset velocity
        self.player.vel_x = 0
        self.player.vel_y = 0
        
        # Equip basic weapon if player doesn't have one
        if not self.player.current_weapon:
            from src.entities.base_weapon import BasicWeapon
            weapon = BasicWeapon()
            self.player.equip_weapon(weapon)
        
        # Reset spawning system
        self.spawn_timer = 0.0
        self.difficulty_timer = 0.0
        self.spawn_interval = 3.0
    
    def handle_events(self, event):
        """Handle pygame events, especially for game over restart"""
        if self.game_over and self.game_over_timer > 0.5:
            # Check for any key press or mouse click to restart
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                self.restart_game()
                return True  # Indicate that we handled this event
                
        # Not handling this event
        return False
    
    def update(self, dt):
        """Update level logic"""
        keys = pygame.key.get_pressed()
        
        # Check for game over state
        if self.game_over:
            self.game_over_timer += dt
            
            # Alternative restart method using key state (more reliable)
            if self.game_over_timer > 0.5:
                # Check if any key is currently pressed
                if any(keys):
                    self.restart_game()
            return
        
        # Check if player health reached 0
        if hasattr(self.player, 'health') and self.player.health <= 0:
            self.trigger_game_over()
            return
        
        # Update timers
        self.spawn_timer += dt
        self.difficulty_timer += dt
        
        # Update player
        self.player.update(dt, keys)
        
        # Update projectiles
        self.projectiles.update(dt)
        self.enemy_projectiles.update(dt)
        
        # Update enemies
        self.enemies.update(dt, self.player.rect.center)
        
        # Spawn new enemies
        self.update_enemy_spawning(dt)
        
        # Handle combat
        self.handle_combat()
        
        # Update camera to follow player
        self.update_camera()
    
    def update_enemy_spawning(self, dt):
        """Handle enemy spawning with weighted random selection and multi-spawning"""
        # Check if it's time to spawn and we haven't hit max enemies
        if self.spawn_timer >= self.spawn_interval and len(self.enemies) < self.max_enemies:
            self.spawn_enemy_group()
            self.spawn_timer = 0.0
            
            # More aggressive spawn rate scaling
            if self.difficulty_timer > 20:  # Start scaling earlier
                reduction = 0.08 if self.difficulty_timer > 60 else 0.04  # Faster reduction later
                self.spawn_interval = max(1.0, self.spawn_interval - reduction)
            
            # Increase multi-spawn potential over time
            if self.difficulty_timer > 45:
                self.max_spawn_count = min(5, self.max_spawn_count + 1)  # Up to 5 enemies at once
            
    def spawn_enemy_group(self):
        """Spawn multiple enemies at once based on difficulty"""
        # Determine how many enemies to spawn
        enemies_to_spawn = self.calculate_spawn_count()
        
        for _ in range(enemies_to_spawn):
            # Don't exceed max enemy limit
            if len(self.enemies) >= self.max_enemies:
                break
                
            selected_enemy = self.select_random_enemy()
            if selected_enemy:
                spawn_x, spawn_y = self.get_random_spawn_position()
                enemy = selected_enemy(spawn_x, spawn_y)
                enemy.set_level(self)
                self.enemies.add(enemy)
    
    def calculate_spawn_count(self):
        """Calculate how many enemies to spawn this time"""
        # Base spawn count increases with time
        base_count = 1
        if self.difficulty_timer > 30:
            base_count = 2
        if self.difficulty_timer > 90:
            base_count = 3
        if self.difficulty_timer > 150:
            base_count = 4
        
        # Random variation (can spawn 1-2 extra sometimes)
        bonus = random.randint(0, 2) if self.difficulty_timer > 60 else random.randint(0, 1)
        
        return min(self.max_spawn_count, base_count + bonus)
    
    def select_random_enemy(self):
        """Select a random enemy type based on weighted probabilities"""
        # Get available enemies based on current difficulty
        available_enemies = []
        total_weight = 0
        
        for enemy_class, (weight, min_time) in self.enemy_spawn_table.items():
            if self.difficulty_timer >= min_time:
                available_enemies.append((enemy_class, weight))
                total_weight += weight
        
        if not available_enemies:
            return None
        
        # Weighted random selection
        roll = random.randint(1, total_weight)
        current_weight = 0
        
        for enemy_class, weight in available_enemies:
            current_weight += weight
            if roll <= current_weight:
                return enemy_class
        
        # Fallback (shouldn't happen)
        return available_enemies[0][0]
            
    def get_random_spawn_position(self):
        """Get a random position on the edge of the level, outside camera view"""
        # Add buffer to spawn enemies outside visible area
        buffer = 100
        
        # Determine spawn area based on camera position
        left_bound = max(0, self.camera_x - buffer)
        right_bound = min(self.level_width, self.camera_x + config.SCREEN_WIDTH + buffer)
        top_bound = max(0, self.camera_y - buffer)
        bottom_bound = min(self.level_height, self.camera_y + config.SCREEN_HEIGHT + buffer)
        
        # Choose random edge
        edge = random.choice(['top', 'bottom', 'left', 'right'])
        
        if edge == 'top':
            return (random.randint(int(left_bound), int(right_bound)), int(top_bound))
        elif edge == 'bottom':
            return (random.randint(int(left_bound), int(right_bound)), int(bottom_bound))
        elif edge == 'left':
            return (int(left_bound), random.randint(int(top_bound), int(bottom_bound)))
        else:  # right
            return (int(right_bound), random.randint(int(top_bound), int(bottom_bound)))
            
    def handle_combat(self):
        """Handle collisions between projectiles and entities"""
        # Player projectiles vs enemies
        for projectile in self.projectiles:
            hit_enemies = pygame.sprite.spritecollide(projectile, self.enemies, False)
            for enemy in hit_enemies:
                damage = getattr(projectile, 'damage', 10)
                if enemy.take_damage(damage):
                    self.enemies_defeated += 1
                    print(f"Enemy defeated! Total defeated: {self.enemies_defeated}, Remaining: {len(self.enemies)}")
                projectile.kill()
                break
        
        # Enemy projectiles vs player
        for projectile in self.enemy_projectiles:
            if projectile.rect.colliderect(self.player.rect):
                damage = getattr(projectile, 'damage', 5)
                if hasattr(self.player, 'take_damage'):
                    self.player.take_damage(damage)
                else:
                    print(f"Player hit for {damage} damage!")
                projectile.kill()
        
        # Enemy melee vs player
        for enemy in self.enemies:
            if enemy.rect.colliderect(self.player.rect) and enemy.can_attack():
                damage = enemy.attack()
                if hasattr(self.player, 'take_damage'):
                    self.player.take_damage(damage)
                else:
                    print(f"Player hit by {enemy.__class__.__name__} for {damage} damage!")

    def update_camera(self):
        """Simple camera that follows player"""
        # Center camera on player
        self.camera_x = self.player.rect.centerx - config.SCREEN_WIDTH // 2
        self.camera_y = self.player.rect.centery - config.SCREEN_HEIGHT // 2
        
        # Clamp camera to level boundaries
        self.camera_x = max(0, min(self.camera_x, self.level_width - config.SCREEN_WIDTH))
        self.camera_y = max(0, min(self.camera_y, self.level_height - config.SCREEN_HEIGHT))
    
    def draw(self, screen, camera=None):
        """Draw everything in the level"""
        # Draw background
        screen.fill(self.bg_color)
        
        # If game over, draw game over screen instead
        if self.game_over:
            self.draw_game_over_screen(screen)
            return
        
        # Draw level boundary visualization (grid for testing)
        self.draw_boundaries(screen)
        
        # Draw player projectiles
        for projectile in self.projectiles:
            draw_rect = projectile.rect.copy()
            draw_rect.x -= self.camera_x
            draw_rect.y -= self.camera_y
            screen.blit(projectile.image, draw_rect)
        
        # Draw enemy projectiles
        for projectile in self.enemy_projectiles:
            draw_rect = projectile.rect.copy()
            draw_rect.x -= self.camera_x
            draw_rect.y -= self.camera_y
            screen.blit(projectile.image, draw_rect)
        
        # Draw enemies with health bars
        for enemy in self.enemies:
            draw_rect = enemy.rect.copy()
            draw_rect.x -= self.camera_x
            draw_rect.y -= self.camera_y
            screen.blit(enemy.image, draw_rect)
            
            # Draw health bar for damaged enemies
            enemy.draw_health_bar(screen, (self.camera_x, self.camera_y))
        
        # Draw weapon (if player has one)
        if self.player.current_weapon:
            weapon_rect = self.player.current_weapon.rect.copy()
            weapon_rect.x -= self.camera_x
            weapon_rect.y -= self.camera_y
            screen.blit(self.player.current_weapon.image, weapon_rect)
        
        # Draw player with camera offset
        self.player.draw(screen, (self.camera_x, self.camera_y))
        
        # Draw UI info
        self.draw_ui(screen)
    
    def draw_boundaries(self, screen):
        """Draw grid to show level boundaries (for testing)"""
        grid_color = (70, 120, 70)
        grid_size = 100
        
        # Draw vertical lines
        for x in range(0, self.level_width, grid_size):
            screen_x = x - self.camera_x
            if 0 <= screen_x <= config.SCREEN_WIDTH:
                pygame.draw.line(screen, grid_color, 
                               (screen_x, 0), 
                               (screen_x, config.SCREEN_HEIGHT))
        
        # Draw horizontal lines
        for y in range(0, self.level_height, grid_size):
            screen_y = y - self.camera_y
            if 0 <= screen_y <= config.SCREEN_HEIGHT:
                pygame.draw.line(screen, grid_color, 
                               (0, screen_y), 
                               (config.SCREEN_WIDTH, screen_y))
    
    def draw_ui(self, screen):
        """Draw essential UI elements: health, defeated enemies, and time"""
        font = pygame.font.Font(None, 24)
        
        # Player health
        if hasattr(self.player, 'health'):
            health_text = font.render(f"Health: {self.player.health}/{self.player.max_health}", True, (255, 255, 255))
            screen.blit(health_text, (10, 10))
        
        # Enemies defeated counter
        defeated_text = font.render(f"Defeated: {self.enemies_defeated}", True, (255, 255, 255))
        screen.blit(defeated_text, (10, 35))
        
        # Time survived
        time_text = font.render(f"Time: {int(self.difficulty_timer)}s", True, (255, 255, 255))
        screen.blit(time_text, (10, 60))
        
        # Controls hint (keep this for usability)
        controls_text = font.render("ESC: Return to Menu", True, (200, 200, 200))
        screen.blit(controls_text, (config.SCREEN_WIDTH - 150, config.SCREEN_HEIGHT - 25))
    
    def trigger_game_over(self):
        """Called when player health reaches 0"""
        self.game_over = True
        self.game_over_timer = 0.0
        self.final_time = int(self.difficulty_timer)
        print(f"GAME OVER! Survived for {self.final_time} seconds")
    
    def restart_game(self):
        """Restart the game from the beginning"""
        # Reset game over state
        self.game_over = False
        self.game_over_timer = 0.0
        self.final_time = 0
        self.enemies_defeated = 0
        
        # Reset player health and position
        if hasattr(self.player, 'health'):
            self.player.health = self.player.max_health
        
        # Reset level state
        self.reset()
        self.on_enter()  # Reinitialize everything
    
    def draw_game_over_screen(self, screen):
        """Draw the game over screen"""
        # Semi-transparent dark overlay
        overlay = pygame.Surface((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))
        
        # Create fonts
        title_font = pygame.font.Font(None, 72)
        subtitle_font = pygame.font.Font(None, 36)
        text_font = pygame.font.Font(None, 28)
        
        # Game Over title
        game_over_text = title_font.render("GAME OVER", True, (255, 50, 50))
        game_over_rect = game_over_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 - 120))
        screen.blit(game_over_text, game_over_rect)
        
        # Survival time
        time_text = subtitle_font.render(f"You survived for {self.final_time} seconds!", True, (255, 255, 255))
        time_rect = time_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 - 60))
        screen.blit(time_text, time_rect)
        
        # Enemies defeated
        enemies_text = text_font.render(f"Enemies defeated: {self.enemies_defeated}", True, (200, 200, 200))
        enemies_rect = enemies_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 - 20))
        screen.blit(enemies_text, enemies_rect)
        
        # Instructions
        if self.game_over_timer > 0.5:  # Only show after small delay
            # Main restart instruction
            restart_text = text_font.render("Press any key to restart", True, (255, 255, 100))
            restart_rect = restart_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 + 40))
            
            # Blinking effect for restart text
            if int(self.game_over_timer * 3) % 2:  # Blink every 0.33 seconds for visibility
                screen.blit(restart_text, restart_rect)
            
            # Additional instruction
            hint_text = text_font.render("(SPACE, ENTER, or click mouse)", True, (180, 180, 180))
            hint_rect = hint_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 + 70))
            screen.blit(hint_text, hint_rect)
        
        # Additional stats - show the final number of enemies that were on screen when game ended
        final_enemies_text = text_font.render(f"Final enemies on screen: {len(self.enemies)}", True, (150, 150, 150))
        final_enemies_rect = final_enemies_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 + 80))
        screen.blit(final_enemies_text, final_enemies_rect)
        
        difficulty_text = text_font.render(f"Difficulty level reached: {max(1, int(self.final_time / 30))}", True, (150, 150, 150))
        difficulty_rect = difficulty_text.get_rect(center=(config.SCREEN_WIDTH // 2, config.SCREEN_HEIGHT // 2 + 110))
        screen.blit(difficulty_text, difficulty_rect)

    def reset(self):
        """Reset level to initial state"""
        super().reset()  # Clears enemy and projectile groups
        self.enemy_projectiles.empty()
        self.spawn_timer = 0.0
        self.difficulty_timer = 0.0
        self.spawn_interval = 2.5  # Reset to faster base rate
        self.wave_number = 1
        self.max_spawn_count = 3  # Reset multi-spawn count