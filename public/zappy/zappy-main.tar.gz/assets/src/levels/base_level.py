import pygame
import config

class BaseLevel:
    def __init__(self, player, level_width=None, level_height=None):
        """Common level attributes"""
        self.player = player
        self.completed = False
        self.reward_tool = None
        
        # Sprite groups (standard across all levels)
        self.enemies = pygame.sprite.Group()
        self.platforms = pygame.sprite.Group()
        self.hazards = pygame.sprite.Group()
        self.collectibles = pygame.sprite.Group()
        self.projectiles = pygame.sprite.Group()  # ← ADD THIS
        
        # Level boundaries - use provided values or defaults
        self.level_width = level_width or config.DEFAULT_LEVEL_WIDTH
        self.level_height = level_height or config.DEFAULT_LEVEL_HEIGHT
        
        # Background
        self.background = None
        self.bg_color = (135, 206, 235)  # Sky blue default

    def update(self, dt):
        """Update all level entities - MUST be implemented by child classes"""
        raise NotImplementedError("Each level must implement update()")
        
    def draw(self, screen, camera):
        """Draw all level elements - MUST be implemented by child classes"""
        raise NotImplementedError("Each level must implement draw()")
        
    def handle_events(self, events):
        """Handle level-specific events (optional override)"""
        pass
        
    def on_enter(self):
        """Called when level starts (optional override)"""
        self.player.set_level(self)
        
    def on_exit(self):
        """Called when level ends (optional override)"""
        pass
        
    def check_completion(self):
        """Check if level objectives are met (optional override)"""
        return self.completed
    
    def get_boundaries(self):
        """Returns the level boundaries as a rect"""
        return pygame.Rect(0, 0, self.level_width, self.level_height)
    
    def clamp_sprite(self, sprite):
        """Keep sprite within level boundaries"""
        sprite.rect.x = max(0, min(sprite.rect.x, self.level_width - sprite.rect.width))
        sprite.rect.y = max(0, min(sprite.rect.y, self.level_height - sprite.rect.height))
        return sprite
    
    def is_within_bounds(self, sprite):
        """Check if sprite is within boundaries"""
        return (0 <= sprite.rect.x <= self.level_width - sprite.rect.width and
                0 <= sprite.rect.y <= self.level_height - sprite.rect.height)
    
    def spawn_projectile(self, projectile):
        """
        Add a projectile to the level.
        Call this when a weapon fires.
        """
        projectile.set_level(self)
        self.projectiles.add(projectile)
        
    def reset(self):
        """Reset level to initial state (optional override)"""
        self.completed = False
        self.enemies.empty()
        self.collectibles.empty()
        self.projectiles.empty()  # ← ADD THIS TOO