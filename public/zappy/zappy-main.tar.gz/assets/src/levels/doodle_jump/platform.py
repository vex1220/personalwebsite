import random
import pygame
from config import DJ_SCREEN_WIDTH

class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, w=68, h=14):
        super().__init__()
        self.image = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(self.image, (60,200,90), (0,0,w,h), border_radius=6)
        pygame.draw.rect(self.image, (25,120,45), (0,0,w,h), 2, border_radius=6)
        self.rect = self.image.get_rect(topleft=(x, y))

        # small chance to move horizontally
        self.moving = random.random() < 0.15
        self.speed  = random.choice([1,2]) if self.moving else 0
        self.dir    = random.choice([-1,1]) if self.moving else 0

    def update(self):
        if self.moving:
            self.rect.x += self.dir * self.speed
            if self.rect.left <= 0 or self.rect.right >= DJ_SCREEN_WIDTH:
                self.dir *= -1