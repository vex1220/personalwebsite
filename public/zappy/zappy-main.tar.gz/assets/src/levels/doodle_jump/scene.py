import random, pygame
from config import (
    DJ_SCREEN_WIDTH, DJ_SCREEN_HEIGHT, DJ_FPS,
    DJ_PLATFORM_COUNT, DJ_SCROLL_TRIGGER_Y
)
from .player import Player
from .platform import Platform

class DoodleJumpScene:
    def __init__(self):
        self.screen_rect = pygame.Rect(0,0,DJ_SCREEN_WIDTH,DJ_SCREEN_HEIGHT)
        self.all_sprites = pygame.sprite.Group()
        self.platforms   = pygame.sprite.Group()
        self.score = 0
        self.game_over = False

        # keep track of which platforms already gave their score
        self.scored_platforms = set() 

        # player
        self.player = Player(DJ_SCREEN_WIDTH//2, DJ_SCREEN_HEIGHT-80)
        self.all_sprites.add(self.player)

        # font for UI
        self.font = pygame.font.Font(None, 36)

        # base platform
        base = Platform(DJ_SCREEN_WIDTH//2 - 50, DJ_SCREEN_HEIGHT-40, 100, 16)
        self.platforms.add(base); self.all_sprites.add(base)

        # if base shouldn't give a point, mark it as already scored
        self.scored_platforms.add(base)

        # seed platforms
        top_y = base.rect.y
        for _ in range(DJ_PLATFORM_COUNT - 1):
            p = self._spawn_platform_above(top_y)
            self.platforms.add(p); self.all_sprites.add(p)
            top_y = min(top_y, p.rect.y)

    # ---- helpers ----
    def _spawn_platform_above(self, max_top_y):
        gap_y = random.randint(60, 100)
        y = max_top_y - gap_y
        x = random.randint(10, DJ_SCREEN_WIDTH - 80)
        return Platform(x, y)

    def _ensure_platforms(self):
        if len(self.platforms) < DJ_PLATFORM_COUNT:
            top_y = min(p.rect.y for p in self.platforms) if self.platforms else DJ_SCREEN_HEIGHT - 40
            while len(self.platforms) < DJ_PLATFORM_COUNT:
                p = self._spawn_platform_above(top_y)
                self.platforms.add(p); self.all_sprites.add(p)
                top_y = min(top_y, p.rect.y)

    def _handle_collisions(self):
        # collide only while falling; snap to platform top; bounce
        if self.player.vel_y > 0:
            for p in self.platforms:
                if self.player.rect.colliderect(p.rect):
                    if self.player.rect.bottom - self.player.vel_y <= p.rect.top + 5:
                        self.player.rect.bottom = p.rect.top
                        self.player.bounce()

                        # scoring: +1 first time we land on this platform
                        if p not in self.scored_platforms:
                            self.score += 1
                            self.scored_platforms.add(p)

                        break

    def _scroll_world(self):
        # when player rises above trigger line, move world down
        if self.player.rect.y < DJ_SCROLL_TRIGGER_Y:
            dy = DJ_SCROLL_TRIGGER_Y - self.player.rect.y
            self.player.rect.y += dy
            for s in self.all_sprites:
                if s is not self.player:
                    s.rect.y += dy

            # recycle off-screen platforms
            for p in list(self.platforms):
                if p.rect.top >= DJ_SCREEN_HEIGHT:
                    self.platforms.remove(p); self.all_sprites.remove(p)

            self._ensure_platforms()
            # no score logic here anymore

    # ---- public scene API ----
    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and self.game_over:
            self.__init__()  # quick reset

    def update(self, dt):
        if self.game_over:
            return
        pressed = pygame.key.get_pressed()
        self.player.update(pressed, dt)
        for p in self.platforms: 
            p.update()
        self._handle_collisions()
        self._scroll_world()
        if self.player.rect.top > DJ_SCREEN_HEIGHT:
            self.game_over = True

    def draw(self, screen):
        screen.fill((245,248,255))
        pygame.draw.line(
            screen, (220,230,250),
            (0, DJ_SCROLL_TRIGGER_Y), (DJ_SCREEN_WIDTH, DJ_SCROLL_TRIGGER_Y), 1
        )
        self.all_sprites.draw(screen)

        # UI
        font = pygame.font.SysFont("arial", 20)
        score_img = font.render(f"Score: {self.score}", True, (20,20,20))
        screen.blit(score_img, score_img.get_rect(midtop=(DJ_SCREEN_WIDTH//2, 8)))

        if self.game_over:
            big = pygame.font.SysFont("arial", 42)
            small = pygame.font.SysFont("arial", 22)
            text_img = big.render("Game Over", True, (200,40,40))
            screen.blit(text_img,
                        text_img.get_rect(center=(DJ_SCREEN_WIDTH//2, DJ_SCREEN_HEIGHT//2-30)))
            info_img = small.render("Press any key to restart", True, (20,20,20))
            screen.blit(info_img,
                        info_img.get_rect(center=(DJ_SCREEN_WIDTH//2, DJ_SCREEN_HEIGHT//2+10)))

    def is_done(self):
        return False

    def next_scene(self):
        return None