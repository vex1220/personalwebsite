import pygame
from config import (
    DJ_PLAYER_SPEED, DJ_GRAVITY, DJ_JUMP_STRENGTH,
    DJ_SCREEN_WIDTH, DJ_SCREEN_HEIGHT, DJ_SPRITE_PATH,
    DJ_SPRITE_COLS, DJ_SPRITE_ROWS, DJ_SPRITE_ROW_TO_USE
)


def _alpha_out_bg(surface, sample_pos=(0, 0), tol=60):
    """
    Make background pixels transparent using a color tolerance around the color
    at sample_pos (default: top-left). Works even if beige varies slightly.
    """
    surf = surface.convert_alpha()
    bg = surf.get_at(sample_pos)  # (r,g,b,a)
    br, bgc, bb, _ = bg

    surf.lock()
    w, h = surf.get_size()
    for y in range(h):
        for x in range(w):
            r, g, b, a = surf.get_at((x, y))
            if abs(r - br) + abs(g - bgc) + abs(b - bb) <= tol:
                # fully transparent
                surf.set_at((x, y), (r, g, b, 0))
    surf.unlock()
    return surf

def _color_diff(c1, c2):
    return abs(c1[0]-c2[0]) + abs(c1[1]-c2[1]) + abs(c1[2]-c2[2])

def _auto_crop_content(sheet, tol=25):
    """Crop to the tight bbox of all pixels that differ from the top-left background color."""
    w, h = sheet.get_size()
    bg = sheet.get_at((0, 0))[:3]  # beige background
    px = pygame.PixelArray(sheet)
    top, left, bottom, right = h, w, -1, -1

    # scan with a stride for speed; then refine edges
    stride = max(1, min(w, h) // 200)
    for y in range(0, h, stride):
        for x in range(0, w, stride):
            rgb = sheet.unmap_rgb(px[x, y])[:3]
            if _color_diff(rgb, bg) > tol:
                if y < top:    top = y
                if y > bottom: bottom = y
                if x < left:   left = x
                if x > right:  right = x
    del px

    if bottom == -1:
        return sheet, (0, 0, w, h), bg  # nothing found; return as-is

    # small padding to avoid clipping outlines
    pad = 2
    left   = max(0, left - pad)
    top    = max(0, top - pad)
    right  = min(w-1, right + pad)
    bottom = min(h-1, bottom + pad)
    rect = pygame.Rect(left, top, right-left+1, bottom-top+1)
    cropped = sheet.subsurface(rect).copy()
    return cropped, rect, bg

def _slice_frames(img, cols=None, rows=None, row_to_use=None):
    """Split the (already-cropped) image into frames.
       If cols/rows are None, choose automatically:
         - very wide image  -> 1 row, cols ~ width/height (square frames)
         - tall grid (like 3x2) -> rows=2, cols=3
    """
    W, H = img.get_size()

    # auto-detect grid if not specified
    if cols is None or rows is None:
        if W >= 1.6 * H:
            rows = 1
            cols = max(2, round(W / H))
            frame_w = H
            frame_h = H
        else:
            # assume the 3x2 sheet
            rows = 2
            cols = 3
            frame_w = W // cols
            frame_h = H // rows
    else:
        frame_w = W // cols
        frame_h = H // rows

    frames = []
    start_row = 0
    end_row = rows
    if row_to_use is not None:
        start_row = max(0, min(rows-1, row_to_use))
        end_row = start_row + 1

    for r in range(start_row, end_row):
        for c in range(cols):
            rect = pygame.Rect(c * frame_w, r * frame_h, frame_w, frame_h)
            frames.append(img.subsurface(rect).copy())
    return frames

def _load_frames_from_sheet(path):
    sheet = pygame.image.load(path).convert_alpha()

    # --- Crop out top logo area ---
    w, h = sheet.get_size()
    crop_top = int(h * 0.35)   # trim "ZAPPY" text
    cropped = sheet.subsurface(pygame.Rect(0, crop_top, w, h - crop_top)).copy()

    # --- Remove beige background everywhere (with tolerance) ---
    cropped = _alpha_out_bg(cropped, sample_pos=(1, 1), tol=70)

    # --- Slice frames ---
    # Use 4 columns, 1 row for your walking strip
    frames = _slice_frames(cropped, cols=4, rows=1)

    return frames


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, size=(64, 64)):  # <-- bumped from 28x28 to 64x64
        super().__init__()

        raw_frames = _load_frames_from_sheet(DJ_SPRITE_PATH)

        # scale for crisp visibility
        w, h = size
        self.frames_right = [pygame.transform.smoothscale(f, (w, h)) for f in raw_frames]
        self.frames_left  = [pygame.transform.flip(f, True, False) for f in self.frames_right]

        self.frame_index = 0
        self.anim_timer = 0.0
        self.ANIM_FPS = 10
        self.facing_left = False

        self.image = self.frames_right[self.frame_index]
        self.rect = self.image.get_rect(center=(x, y))

        self.vel_x = 0
        self.vel_y = 0
        self.highest_y = y

    def _pick_image(self, dt):
        moving = self.vel_x != 0
        frames = self.frames_left if self.facing_left else self.frames_right

        if moving and len(frames) > 1:
            self.anim_timer += dt
            step = 1.0 / self.ANIM_FPS
            while self.anim_timer >= step:
                self.anim_timer -= step
                self.frame_index = (self.frame_index + 1) % len(frames)
        else:
            self.frame_index = 0

        self.image = frames[self.frame_index]

    def update(self, pressed=None, dt=0.016):
        if pressed is None:
            pressed = pygame.key.get_pressed()

        if pressed[pygame.K_LEFT] or pressed[pygame.K_a]:
            self.vel_x = -DJ_PLAYER_SPEED
            self.facing_left = True
        elif pressed[pygame.K_RIGHT] or pressed[pygame.K_d]:
            self.vel_x = DJ_PLAYER_SPEED
            self.facing_left = False
        else:
            self.vel_x = 0

        self.rect.x += self.vel_x
        self.vel_y += DJ_GRAVITY
        self.rect.y += self.vel_y

        if self.rect.right < 0: self.rect.left = DJ_SCREEN_WIDTH
        elif self.rect.left > DJ_SCREEN_WIDTH: self.rect.right = 0

        if self.rect.y < self.highest_y:
            self.highest_y = self.rect.y

        self._pick_image(dt)

    def bounce(self):
        self.vel_y = -DJ_JUMP_STRENGTH