
#how to run the standalone:
#python -m src.levels.doodle_jump.run
import asyncio
import pygame, sys
from config import DJ_SCREEN_WIDTH, DJ_SCREEN_HEIGHT, DJ_FPS, DJ_SPRITE_PATH
from .scene import DoodleJumpScene

async def main(standalone=True):
    pygame.init()
    screen = pygame.display.set_mode((DJ_SCREEN_WIDTH, DJ_SCREEN_HEIGHT))
    pygame.display.set_caption("Zappy — Doodle Jump (dev run)")

    # set window icon
    try:
        icon_img = pygame.image.load(DJ_SPRITE_PATH).convert_alpha()
        # scale small to keep OS happy
        icon_img = pygame.transform.smoothscale(icon_img, (32, 32))
        pygame.display.set_icon(icon_img)
    except Exception as e:
        # Non-fatal if icon missing
        print(f"[warn] Could not set icon: {e}")

    clock = pygame.time.Clock()

    scene = DoodleJumpScene()
    running = True
    while running:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                running = False  # ESC to return to menu
            scene.handle_event(e)

        dt = clock.get_time() / 1000.0
        scene.update(dt)
        scene.draw(screen)
        pygame.display.flip()
        clock.tick(DJ_FPS)
        await asyncio.sleep(0)

    # Only quit pygame if running standalone, not from menu
    if standalone:
        pygame.quit(); sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
