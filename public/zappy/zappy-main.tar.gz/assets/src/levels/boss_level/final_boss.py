import pygame
from src.levels.platform import Platform
from src.entities.player import Player
import config


class FinalBossLevel:
    def __init__(self, screen):
        self.screen = screen
        self.ground_y = int(config.SCREEN_HEIGHT * 0.7)
        self.ground = Platform(0, self.ground_y, config.SCREEN_WIDTH, config.SCREEN_HEIGHT - self.ground_y, (100, 200, 100))
        self.platforms = [
            Platform(300, 450, 100, 15),
            Platform(500, 380, 100, 15),
            Platform(650, 320, 100, 15)
        ]
        self.player = Player(100, self.ground_y - 60)

    def update(self, dt):
        # Use dt and pass platforms as list to player.update
        self.player.update(dt, self.platforms + [self.ground])

    def draw(self):
        self.screen.fill((255, 255, 255))
        for platform in self.platforms:
            platform.draw(self.screen)
        self.ground.draw(self.screen)
        self.player.draw(self.screen)
