import pygame


class Platform(pygame.sprite.Sprite):
    """A simple rectangular platform implemented as a pygame Sprite.

    This class provides an `image` and `rect` so it can be added to
    `pygame.sprite.Group()` instances and can also be drawn via a
    custom `draw()` helper to preserve existing usage.
    """

    def __init__(self, x, y, w, h, color=(150, 150, 255)):
        super().__init__()
        # Surface used by sprite groups' draw() if desired
        self.image = pygame.Surface((w, h), pygame.SRCALPHA)
        self.image.fill(color)
        # Rect used for collision and positioning
        self.rect = self.image.get_rect(topleft=(x, y))
        self.color = color

    def draw(self, screen):
        # Keep the simple draw API used across levels
        screen.blit(self.image, self.rect)


