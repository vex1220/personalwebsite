import pygame
from config import PLAYER_SPEED, GRAVITY, JUMP_STRENGTH, SCREEN_HEIGHT, SCREEN_WIDTH


class Player:
    def __init__(self, x, y, width=24, height=36):
        # Position and rect
        self.rect = pygame.Rect(int(x), int(y), width, height)
        self.prev_rect = self.rect.copy()

        # Physics
        self.vel_x = 0
        self.vel_y = 0
        self.on_ground = False

        # Jump helpers
        self.coyote_time = 0.12
        self.coyote_timer = 0.0
        self.jump_buffer_time = 0.12
        self.jump_buffer_timer = 0.0
        self._jump_held = False
        self.jump_cooldown = 0.08
        self.jump_cooldown_timer = 0.0

        # Appearance
        self.color = (255, 0, 0)

        # Lives
        self.max_lives = 4
        self.lives = self.max_lives

        # Invulnerability after taking damage
        self.invulnerable = False
        self.invulnerable_timer = 0.0
        self.invulnerable_duration = 0.5

        # Facing (for bark direction)
        self.facing_right = True

        # Bark ability
        self.is_barking = False
        self.bark_duration = 0.22
        self.bark_timer = 0.0
        # Make bark range small: same width as player model
        self.bark_range = width
        # Bark height similar to player height for more precise hits
        self.bark_height = height
        self.bark_rect = None
        self.bark_damage = 1
        # Require a 3-second buffer between barks
        self.bark_cooldown = 3.0
        self.bark_cooldown_timer = 0.0
        
        # Level reference (for compatibility with base_level.py)
        self.current_level = None

    def bark(self):
        # Respect cooldown
        if self.bark_cooldown_timer > 0.0:
            return None
        fx = 1 if getattr(self, 'facing_right', True) else -1
        if fx > 0:
            bx = self.rect.right
            bw = self.bark_range
        else:
            bx = self.rect.left - self.bark_range
            bw = self.bark_range
        by = int(self.rect.centery - self.bark_height // 2)
        bh = self.bark_height
        self.bark_rect = pygame.Rect(int(bx), int(by), int(bw), int(bh))
        self.is_barking = True
        self.bark_timer = self.bark_duration
        self.bark_cooldown_timer = self.bark_cooldown
        return self.bark_rect

    def update(self, dt, platforms=None):
        # store previous rect and ground state
        self.prev_rect = self.rect.copy()
        self.prev_on_ground = self.on_ground

        # Timers
        if self.coyote_timer > 0.0:
            self.coyote_timer = max(0.0, self.coyote_timer - dt)
        if self.jump_buffer_timer > 0.0:
            self.jump_buffer_timer = max(0.0, self.jump_buffer_timer - dt)
        if self.jump_cooldown_timer > 0.0:
            self.jump_cooldown_timer = max(0.0, self.jump_cooldown_timer - dt)
        if self.invulnerable_timer > 0.0:
            self.invulnerable_timer = max(0.0, self.invulnerable_timer - dt)
            if self.invulnerable_timer <= 0.0:
                self.invulnerable = False
        if self.is_barking:
            self.bark_timer = max(0.0, self.bark_timer - dt)
            if self.bark_timer <= 0.0:
                self.is_barking = False
                self.bark_rect = None
        if self.bark_cooldown_timer > 0.0:
            self.bark_cooldown_timer = max(0.0, self.bark_cooldown_timer - dt)

        # Input, physics, movement
        self.handle_input()
        self.apply_physics(dt)
        self.move(dt)

        if platforms:
            self.handle_platform_collisions(platforms)

    def handle_input(self):
        keys = pygame.key.get_pressed()

        # Horizontal movement
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.vel_x = -PLAYER_SPEED
            self.facing_right = False
        elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.vel_x = PLAYER_SPEED
            self.facing_right = True
        else:
            self.vel_x = 0

        # Jump logic
        jump_pressed = keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]
        newly_pressed = jump_pressed and not self._jump_held
        
        # Only set jump buffer on newly pressed, not while held
        if newly_pressed:
            self.jump_buffer_timer = self.jump_buffer_time
            
        can_jump = self.on_ground or self.coyote_timer > 0.0
        if newly_pressed and can_jump and self.jump_cooldown_timer <= 0.0:
            self.vel_y = -JUMP_STRENGTH
            self.on_ground = False
            self.coyote_timer = 0.0
            self.jump_buffer_timer = 0.0
            self.jump_cooldown_timer = self.jump_cooldown
        self._jump_held = jump_pressed

    def apply_physics(self, dt):
        if not self.on_ground:
            self.vel_y += GRAVITY * dt * 60
        if self.vel_y > 20:
            self.vel_y = 20

    def take_damage(self, amount=1):
        if self.invulnerable:
            return False
        self.lives = max(0, self.lives - amount)
        self.invulnerable = True
        self.invulnerable_timer = self.invulnerable_duration
        print(f"Player took damage! Lives: {self.lives}/{self.max_lives}, Invulnerable for {self.invulnerable_duration}s")
        return True

    def move(self, dt):
        self.rect.x += int(self.vel_x * dt * 60)
        self.check_horizontal_boundaries()
        self.rect.y += int(self.vel_y * dt * 60)
        self.check_vertical_boundaries()

    def handle_platform_collisions(self, platforms):
        collided = None
        for p in platforms:
            plat_rect = getattr(p, 'rect', None)
            if plat_rect and self.rect.colliderect(plat_rect):
                collided = plat_rect
                break
        if not collided:
            if getattr(self, 'prev_on_ground', False):
                self.coyote_timer = self.coyote_time
            self.on_ground = False
            return
        # Landing
        if self.prev_rect.bottom <= collided.top and self.rect.bottom >= collided.top:
            self.rect.bottom = collided.top
            self.vel_y = 0
            self.on_ground = True
            self.coyote_timer = self.coyote_time
            # Only execute buffered jump if player is currently holding jump button
            keys = pygame.key.get_pressed()
            jump_held = keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]
            if self.jump_buffer_timer > 0.0 and self.jump_cooldown_timer <= 0.0 and jump_held:
                self.vel_y = -JUMP_STRENGTH
                self.on_ground = False
                self.jump_buffer_timer = 0.0
                self.jump_cooldown_timer = self.jump_cooldown
            else:
                # Clear jump buffer if not jumping
                self.jump_buffer_timer = 0.0
        # Ceiling
        elif self.prev_rect.top >= collided.bottom and self.rect.top <= collided.bottom:
            self.rect.top = collided.bottom
            self.vel_y = 0
            self.jump_buffer_timer = 0.0
            self.coyote_timer = 0.0
            self.jump_cooldown_timer = self.jump_cooldown
        else:
            if self.vel_y > 0:
                self.rect.bottom = collided.top
                self.vel_y = 0
                self.on_ground = True
                self.coyote_timer = self.coyote_time
                # Only execute buffered jump if player is currently holding jump button
                keys = pygame.key.get_pressed()
                jump_held = keys[pygame.K_UP] or keys[pygame.K_w] or keys[pygame.K_SPACE]
                if self.jump_buffer_timer > 0.0 and self.jump_cooldown_timer <= 0.0 and jump_held:
                    self.vel_y = -JUMP_STRENGTH
                    self.on_ground = False
                    self.jump_buffer_timer = 0.0
                    self.jump_cooldown_timer = self.jump_cooldown
                else:
                    # Clear jump buffer if not jumping
                    self.jump_buffer_timer = 0.0
            elif self.vel_y < 0:
                self.rect.top = collided.bottom
                self.vel_y = 0

    def check_horizontal_boundaries(self):
        if self.rect.left < 0:
            self.rect.left = 0
            self.vel_x = 0
        elif self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
            self.vel_x = 0

    def check_vertical_boundaries(self):
        if self.rect.top < 0:
            self.rect.top = 0
            self.vel_y = 0
        elif self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT
            self.vel_y = 0
            self.on_ground = True

    def set_level(self, level):
        """Set the current level reference (for compatibility with base_level.py)"""
        self.current_level = level

    def draw(self, screen):
        # Flash red/white when invulnerable for visual feedback
        if self.invulnerable and self.invulnerable_timer > 0:
            # Flash between red and white every 0.1 seconds
            flash_cycle = int(self.invulnerable_timer * 10) % 2
            color = (255, 255, 255) if flash_cycle == 0 else self.color
        else:
            color = self.color
            
        pygame.draw.rect(screen, color, self.rect)
        
        # Draw lives as small hearts in top-left corner
        for i in range(self.lives):
            heart_x = 10 + i * 25
            heart_y = 10
            pygame.draw.circle(screen, (255, 100, 100), (heart_x, heart_y), 8)
            pygame.draw.circle(screen, (255, 50, 50), (heart_x, heart_y), 6)
        
        if self.is_barking and self.bark_rect:
            try:
                pygame.draw.rect(screen, (255, 220, 100), self.bark_rect, 2)
            except Exception:
                pass