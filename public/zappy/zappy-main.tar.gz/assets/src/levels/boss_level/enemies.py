import config
from src.levels.boss_level.enemy import Enemy
import math
import pygame
from src.levels.boss_level.platform import Platform


class BossTouchEnemy(Enemy):
    """Boss-level-specific static enemy that damages the player on contact.

    This mirrors the previous TouchEnemy behavior but is placed inside the boss
    level package so boss-specific enemy types can live alongside the level.
    """

    def __init__(self, x, y, width=50, height=50, health=8):
        # Boss has 8 health units by default (displayed as a proportional bar)
        super().__init__(x, y, width, height, health, speed=0)
        try:
            self.image.fill((180, 30, 30))
        except Exception:
            pass

        # Per-enemy cooldown to damage player
        self.player_damage_cooldown = 0.0
        self.player_damage_cooldown_duration = 5.0

        # Movement (patrol)
        # speed is in pixels per frame-unit (we'll scale by dt*60 like apply_movement)
        # increase boss movement speed to make the fight more challenging
        self.patrol_speed = 3.0
        self.direction = 1  # 1 = right, -1 = left

        # Patrol across the full screen width by default (stay on-screen)
        self.patrol_min = 0
        self.patrol_max = config.SCREEN_WIDTH

        # Shooting (pellets)
        self.shoot_interval = 3.0
        self.shoot_timer = self.shoot_interval
        # Pellet parameters
        # increase pellet speed for added difficulty
        self.pellet_speed = 7.0
        self.pellet_size = (8, 8)
        # Firing animation
        self.is_firing = False
        self.firing_duration = 0.35
        self.firing_timer = 0.0
        # Flash effect when taking damage
        self.flash_timer = 0.0
        self.flash_duration = 0.25

    def update(self, dt, player_pos=None):
        # Update damage cooldowns - these prevent rapid damage/being damaged
        if self.damage_cooldown > 0:
            self.damage_cooldown = max(0.0, self.damage_cooldown - dt)
        if self.player_damage_cooldown > 0:
            self.player_damage_cooldown = max(0.0, self.player_damage_cooldown - dt)

        # Flash timer countdown (visual hit feedback)
        if getattr(self, 'flash_timer', 0.0) > 0.0:
            self.flash_timer = max(0.0, self.flash_timer - dt)

        # Patrol movement: move horizontally between patrol_min and patrol_max
        move_amount = self.patrol_speed * self.direction * dt * 60
        self.rect.x += int(move_amount)

        # Reverse direction if we've hit patrol bounds
        if self.rect.x <= self.patrol_min:
            self.rect.x = self.patrol_min
            self.direction = 1
        elif self.rect.x + self.rect.width >= self.patrol_max:
            self.rect.x = self.patrol_max - self.rect.width
            self.direction = -1

        # Update facing
        self.facing_right = self.direction > 0

        # Shooting timer
        if self.shoot_timer > 0:
            self.shoot_timer = max(0.0, self.shoot_timer - dt)
        if self.shoot_timer <= 0.0:
            self.shoot_timer = self.shoot_interval
            # start firing animation
            self.is_firing = True
            self.firing_timer = self.firing_duration
            # Spawn 10 pellets in an arc from left (180deg) to right (0deg)
            pellets_count = 10
            for i in range(pellets_count):
                angle_deg = 180.0 - (180.0 / (pellets_count - 1)) * i
                rad = math.radians(angle_deg)
                dx = math.cos(rad)
                dy = -math.sin(rad)  # screen y is down, so invert
                # Spawn slightly above the boss center so upward pellets don't instantly collide
                spawn_x = self.rect.centerx
                spawn_y = self.rect.centery - (self.rect.height // 2) - 6
                p = Pellet(spawn_x, spawn_y, self.pellet_size[0], self.pellet_size[1], dx, dy, speed=self.pellet_speed)
                # assign level so pellet can be removed/clamped
                try:
                    self.current_level.hazards.add(p)
                    p.set_level(self.current_level)
                except Exception:
                    # fallback: do nothing if no level
                    pass

        # Firing animation timer countdown
        if self.is_firing:
            self.firing_timer = max(0.0, self.firing_timer - dt)
            if self.firing_timer <= 0.0:
                self.is_firing = False

    def can_damage_player(self):
        return self.player_damage_cooldown <= 0.0

    def draw(self, screen, camera_offset=(0, 0)):
        # Default draw from parent (image + small health if enabled)
        super().draw(screen, camera_offset)

        # Draw flash overlay if recently hit
        if getattr(self, 'flash_timer', 0.0) > 0.0:
            try:
                # Draw a quick white rectangle outline to indicate hit
                rx = self.rect.x - camera_offset[0]
                ry = self.rect.y - camera_offset[1]
                pygame.draw.rect(screen, (255, 255, 255), pygame.Rect(rx, ry, self.rect.width, self.rect.height), 3)
            except Exception:
                pass

        # Draw a firing muzzle/glow when firing
        if self.is_firing:
            try:
                # draw a bright circle above the boss to indicate firing
                cx = self.rect.centerx - camera_offset[0]
                cy = self.rect.top - camera_offset[1] - 6
                pygame.draw.circle(screen, (255, 200, 50), (cx, cy), max(6, self.rect.width // 6))
            except Exception:
                pass

        # Also draw a small health bar above the boss
        try:
            bar_w = max(40, self.rect.width)
            bar_h = 6
            bx = self.rect.centerx - bar_w // 2 - camera_offset[0]
            by = self.rect.top - 12 - camera_offset[1]
            # Background
            bg_rect = pygame.Rect(bx, by, bar_w, bar_h)
            pygame.draw.rect(screen, (120, 20, 20), bg_rect)
            # Foreground proportional to health
            pct = max(0.0, min(1.0, self.health / max(1, self.max_health)))
            fg_rect = pygame.Rect(bx, by, int(bar_w * pct), bar_h)
            pygame.draw.rect(screen, (50, 220, 50), fg_rect)
            # Border
            pygame.draw.rect(screen, (255, 255, 255), bg_rect, 1)
        except Exception:
            pass


class Pellet(pygame.sprite.Sprite):
    """Simple projectile fired by boss. Subclasses pygame.sprite.Sprite so
    it can be stored in level.hazards group and drawn/updated uniformly.
    """
    def __init__(self, x, y, w, h, dir_x, dir_y, speed=3.5, lifetime=5.0, color=(255,200,50)):
        super().__init__()
        self.image = pygame.Surface((w, h), pygame.SRCALPHA)
        self.image.fill(color)
        self.rect = self.image.get_rect(center=(int(x), int(y)))
        # velocity normalized
        vec = pygame.math.Vector2(dir_x, dir_y)
        if vec.length() == 0:
            vec = pygame.math.Vector2(1, 0)
        else:
            vec = vec.normalize()
        self.vel = vec * speed
        self.lifetime = lifetime
        self.current_level = None

    def set_level(self, level):
        self.current_level = level

    def update(self, dt):
        # Move
        self.rect.x += int(self.vel.x * dt * 60)
        self.rect.y += int(self.vel.y * dt * 60)

        # Lifetime countdown
        self.lifetime -= dt
        if self.lifetime <= 0:
            self.kill()
            return

        # Remove if outside level boundaries (if level available)
        if self.current_level:
            bounds = self.current_level.get_boundaries()
            if not bounds.colliderect(self.rect):
                self.kill()

    def draw(self, screen, camera_offset=(0,0)):
        screen.blit(self.image, (self.rect.x - camera_offset[0], self.rect.y - camera_offset[1]))
