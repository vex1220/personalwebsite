from .level import BossLevel

__all__ = ["BossLevel"]
