import pygame
import config
from src.levels.base_level import BaseLevel
from src.levels.boss_level.platform import Platform
from src.levels.boss_level.player import Player
from src.levels.boss_level.enemies import BossTouchEnemy


class BossLevel(BaseLevel):
    """Simple boss arena level compartmentalized in its own package.

    Ground is a horizontal strip located at 70% of the screen height.
    A few static platforms are placed above ground that the player can use to dodge.
    """

    def __init__(self, player=None, level_width=None, level_height=None):
        super().__init__(player, level_width, level_height)

        # Compute ground Y position at 70% of screen height
        self.ground_y = int(config.SCREEN_HEIGHT * 0.7)

        # Create a ground platform spanning the screen
        ground_height = config.SCREEN_HEIGHT - self.ground_y
        self.ground = Platform(0, self.ground_y, config.SCREEN_WIDTH, ground_height, (100, 180, 100))
        self.platforms.add(self.ground)

        # Add some small platforms above the ground for the player
        plat_defs = [
            (150, self.ground_y - 80, 120, 16),
            (350, self.ground_y - 140, 120, 16),
            (600, self.ground_y - 100, 100, 16),
        ]
        for x, y, w, h in plat_defs:
            p = Platform(x, y, w, h, (150, 150, 255))
            self.platforms.add(p)

        # If no player provided, create one near left side of ground
        if not self.player:
            px = 60
            py = self.ground_y - 60
            self.player = Player(px, py)

        # Add a static touch enemy somewhere on the ground
        self.touch_enemy = BossTouchEnemy(420, self.ground_y - 50, width=50, height=50)
        self.touch_enemy.set_level(self)
        self.enemies.add(self.touch_enemy)
        # Timing / end-screen state
        self.boss_start_time = None
        self.end_screen_active = False
        self.final_score = None
        self.end_elapsed = None
        self.end_outcome = None  # 'victory' or 'defeat'
        # Requests for launcher loop (restart / exit to menu)
        self._restart_requested = False
        self._exit_requested = False

    def on_enter(self):
        """Called when this level begins."""
        try:
            self.player.set_level(self)
        except Exception:
            pass
        try:
            self.boss_start_time = pygame.time.get_ticks() / 1000.0
        except Exception:
            self.boss_start_time = None
        self.end_screen_active = False
        self.final_score = None
        self.end_elapsed = None
        self.end_outcome = None
        self._restart_requested = False
        self._exit_requested = False
        # Simple transient effects list (particles, hit pings)
        # Each effect is a dict: {pos: (x,y), ttl: float, color: (r,g,b), size: int}
        self.effects = []

    def handle_events(self, event):
        """Handle forwarded events from the main game loop (used for input like barking)."""
        try:
            # If showing end-screen, capture restart/menu input first
            if self.end_screen_active:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self._restart_requested = True
                    if event.key == pygame.K_m or event.key == pygame.K_ESCAPE:
                        self._exit_requested = True
                return

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # Left click -> player bark
                if hasattr(self, 'player') and self.player:
                    try:
                        self.player.bark()
                    except Exception:
                        pass
        except Exception:
            pass

    def update(self, dt):
        # If the end screen is active, only advance lightweight timers/effects
        if self.end_screen_active:
            # update transient effects so the overlay can still show subtle animations
            new_effects = []
            for fx in list(self.effects):
                try:
                    fx['ttl'] -= dt
                    if fx['ttl'] > 0:
                        new_effects.append(fx)
                except Exception:
                    pass
            self.effects = new_effects
            return

        # Pass platforms (list) to player's update so it can resolve collisions
        self.player.update(dt, list(self.platforms))

        # Update enemies
        for e in list(self.enemies):
            e.update(dt, player_pos=self.player.rect.center)

        # Check collision between player and touch enemies using rect checks
        for enemy in list(self.enemies):
            if hasattr(enemy, 'rect') and self.player.rect.colliderect(enemy.rect):
                # Check if player is jumping on top of enemy (should damage enemy, not player)
                player_bottom = self.player.rect.bottom
                player_prev_bottom = getattr(self.player, 'prev_rect', self.player.rect).bottom
                enemy_top = enemy.rect.top
                enemy_center_y = enemy.rect.centery
                
                # Player is jumping on top if:
                # 1. Player is falling (positive velocity or was above enemy previously)
                # 2. Player's bottom is close to enemy's top
                # 3. Player's center is above enemy's center
                is_jumping_on_top = (
                    self.player.vel_y > 0 and  # Player is falling
                    player_prev_bottom <= enemy_top + 10 and  # Player was above or just touching enemy top
                    player_bottom > enemy_top and  # Player is now overlapping enemy from above
                    self.player.rect.centery < enemy_center_y  # Player center is above enemy center
                )
                
                # Debug output
                if hasattr(self, '_debug_collision') and self._debug_collision:
                    print(f"Collision detected - Jumping on top: {is_jumping_on_top}")
                    print(f"  Player vel_y: {self.player.vel_y}")
                    print(f"  Player prev bottom: {player_prev_bottom}, current: {player_bottom}")
                    print(f"  Enemy top: {enemy_top}, center_y: {enemy_center_y}")
                    print(f"  Player center_y: {self.player.rect.centery}")
                
                if is_jumping_on_top:
                    # Player jumped on enemy - damage the enemy and make player bounce
                    if hasattr(enemy, 'take_damage') and hasattr(enemy, 'damage_cooldown') and enemy.damage_cooldown <= 0:
                        enemy.take_damage(1)
                        # Make player bounce up slightly
                        self.player.vel_y = -8  # Small bounce
                        self.player.rect.bottom = enemy.rect.top  # Position player on top
                        
                        # Add visual effect for successful stomp
                        try:
                            self.effects.append({
                                'pos': (enemy.rect.centerx, enemy.rect.top),
                                'ttl': 0.3,
                                'color': (255, 255, 100),
                                'size': 8,
                            })
                        except Exception:
                            pass
                else:
                    # Regular collision - damage player if not invulnerable
                    if hasattr(enemy, 'can_damage_player') and enemy.can_damage_player() and not self.player.invulnerable:
                        if self.player.take_damage(1):
                            enemy.player_damage_cooldown = getattr(enemy, 'player_damage_cooldown_duration', 5.0)

        # Update hazards (projectiles) and check collisions with player
        for h in list(self.hazards):
            try:
                h.update(dt)
            except TypeError:
                # Some hazard sprites may expect (dt,) or no args; try no-arg update
                try:
                    h.update()
                except Exception:
                    pass

            # Pellet-player collision: damage player and remove pellet
            if hasattr(h, 'rect') and self.player.rect.colliderect(h.rect):
                try:
                    # Only damage player if not invulnerable
                    if not self.player.invulnerable:
                        if self.player.take_damage(1):
                            # remove pellet on successful hit
                            h.kill()
                            # Add hit effect
                            try:
                                self.effects.append({
                                    'pos': self.player.rect.center,
                                    'ttl': 0.4,
                                    'color': (255, 100, 100),
                                    'size': 6,
                                })
                            except Exception:
                                pass
                    else:
                        # Still remove pellet even if player is invulnerable
                        h.kill()
                except Exception:
                    pass

        # Handle player bark hitting enemies: if the player has an active bark_rect,
        # apply damage to enemies that intersect it (only once per bark).
        try:
            if getattr(self.player, 'bark_rect', None):
                for enemy in list(self.enemies):
                    try:
                        # Only let the bark affect the boss enemy(s)
                        if isinstance(enemy, BossTouchEnemy) and hasattr(enemy, 'rect') and enemy.rect.colliderect(self.player.bark_rect):
                            # apply bark damage; take_damage returns True if enemy died
                            enemy.take_damage(getattr(self.player, 'bark_damage', 1))
                            # Clear the player's bark immediately so it only deals one hit per bark action
                            try:
                                self.player.is_barking = False
                                self.player.bark_timer = 0.0
                                self.player.bark_rect = None
                            except Exception:
                                pass
                            # Trigger boss flash and a small hit effect
                            try:
                                if hasattr(enemy, 'flash_duration'):
                                    enemy.flash_timer = getattr(enemy, 'flash_duration', 0.25)
                            except Exception:
                                pass
                            try:
                                # spawn a small effect at the enemy center
                                self.effects.append({
                                    'pos': enemy.rect.center,
                                    'ttl': 0.5,
                                    'color': (255, 220, 80),
                                    'size': 6,
                                })
                            except Exception:
                                pass
                            # Only apply to one boss instance per bark, stop checking further enemies
                            break
                    except Exception:
                        pass
        except Exception:
            pass

        # Update transient effects (particles)
        new_effects = []
        for fx in list(self.effects):
            try:
                fx['ttl'] -= dt
                if fx['ttl'] > 0:
                    new_effects.append(fx)
            except Exception:
                pass
        self.effects = new_effects

        # Check for boss death or player death to trigger end-screen
        try:
            # Robust boss check: if there are no BossTouchEnemy instances left in the enemies group
            boss_exists = any([isinstance(e, BossTouchEnemy) for e in list(self.enemies)])
            if not boss_exists and not self.end_screen_active:
                now = pygame.time.get_ticks() / 1000.0
                if self.boss_start_time is None:
                    self.boss_start_time = now
                elapsed = max(0.0, now - self.boss_start_time)
                self.end_elapsed = elapsed
                # Compute score using configurable constants and floor to a minimum so
                # players can still earn points even after long fights
                try:
                    import config as _cfg
                    start = getattr(_cfg, 'SCORE_START', 10000)
                    decay = getattr(_cfg, 'SCORE_DECAY_RATE', 500)
                    floor = getattr(_cfg, 'SCORE_MIN', 100)
                except Exception:
                    start = 10000
                    decay = 500
                    floor = 100

                score = max(floor, int(start - elapsed * decay))
                self.final_score = score
                self.end_outcome = 'victory'
                self.end_screen_active = True

            # Player death -> Game Over
            if getattr(self, 'player', None) and getattr(self.player, 'lives', 1) <= 0 and not self.end_screen_active:
                self.final_score = 0
                self.end_elapsed = None
                self.end_outcome = 'defeat'
                self.end_screen_active = True
        except Exception:
            pass

    def draw(self, screen, camera_offset=(0, 0)):
        # Background
        screen.fill(self.bg_color)

        # Draw platforms
        for plat in self.platforms:
            plat.draw(screen)

        # Draw enemies
        for e in self.enemies:
            try:
                e.draw(screen, camera_offset)
            except Exception:
                if hasattr(e, 'image') and hasattr(e, 'rect'):
                    screen.blit(e.image, e.rect)

        # Draw hazards (pellets)
        for h in self.hazards:
            try:
                h.draw(screen, camera_offset)
            except Exception:
                if hasattr(h, 'image') and hasattr(h, 'rect'):
                    screen.blit(h.image, h.rect)

        # Draw transient effects (particles/hit pings)
        try:
            for fx in list(self.effects):
                try:
                    px, py = fx.get('pos', (0, 0))
                    size = int(fx.get('size', 4))
                    color = fx.get('color', (255, 220, 80))
                    pygame.draw.circle(screen, color, (int(px - camera_offset[0]), int(py - camera_offset[1])), size)
                except Exception:
                    pass
        except Exception:
            pass

        # Draw player
        self.player.draw(screen)

        # If end-screen active, draw overlay
        if self.end_screen_active:
            try:
                pygame.font.init()
                w = screen.get_width()
                h = screen.get_height()
                overlay = pygame.Surface((w, h), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 160))
                screen.blit(overlay, (0, 0))

                title_font = pygame.font.SysFont(None, 56)
                font = pygame.font.SysFont(None, 36)
                small = pygame.font.SysFont(None, 24)

                if getattr(self, 'end_outcome', None) == 'defeat':
                    title = title_font.render("Game Over!", True, (255, 100, 100))
                else:
                    title = title_font.render("Victory! Boss Defeated", True, (255, 240, 140))
                screen.blit(title, title.get_rect(center=(w // 2, int(h * 0.18))))

                # Score display
                score_text = f"Score: {getattr(self, 'final_score', 0)}"
                s_surf = font.render(score_text, True, (220, 220, 220))
                screen.blit(s_surf, s_surf.get_rect(center=(w // 2, int(h * 0.29))))

                # Time display
                if self.end_elapsed is not None:
                    t_surf = small.render(f"Time: {self.end_elapsed:.2f}s", True, (200, 200, 200))
                    screen.blit(t_surf, t_surf.get_rect(center=(w // 2, int(h * 0.36))))

                # Instructions
                instr = font.render("Press R to Restart, M or ESC to return to Menu", True, (200, 200, 255))
                screen.blit(instr, instr.get_rect(center=(w // 2, int(h * 0.48))))
            except Exception:
                pass

