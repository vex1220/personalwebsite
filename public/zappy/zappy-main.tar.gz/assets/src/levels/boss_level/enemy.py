import pygame
import config

class Enemy(pygame.sprite.Sprite):
    """
    Description: Provides common functionality for all enemy types including
    health management, collision detection, movement, and level boundary awareness.
    All enemy classes should inherit from this base class.
    """

    def __init__(self, x, y, width=50, height=50, health=100, speed=2):
        super().__init__()

        # Visual representation (child classes should override this)
        self.image = pygame.Surface((width, height))
        self.image.fill((255, 0, 0))  # Default red color
        self.rect = self.image.get_rect(topleft=(x, y))

        #Core attributes
        self.max_health = health
        self.health = health
        self.speed = speed
        self.is_alive = True

        #Movement 
        self.velocity = pygame.math.Vector2(0, 0)
        self.direction = pygame.math.Vector2(0, 0)

        # Level reference (set by level when added)
        self.current_level = None
        
        # Animation/state tracking
        self.facing_right = True
        self.state = "idle"  # idle, moving, attacking, hurt
        
        # Damage cooldown (prevents rapid damage)
        self.damage_cooldown = 0
        self.damage_cooldown_duration = 0.5  # seconds

    def set_level(self, level):
        """
        Set reference to the level this enemy is in.
        Called by the level when enemy is added.
        """
        self.current_level = level
    
    def take_damage(self, damage):
        """Updates damage and returns true if enemy died"""
        if not self.is_alive:
            return False
        
        # Don't take damage if still in damage cooldown
        if self.damage_cooldown > 0:
            return False
            
        self.health -= damage
        self.damage_cooldown = self.damage_cooldown_duration
        self.state = "hurt"
        print(f"Enemy took {damage} damage! Health: {self.health}/{self.max_health}")

        # Check for death
        if self.health <= 0:
            self.health = 0
            self.die()
            print("Enemy died!")
            return True
            
        return False
    
    def die(self):
        """
        Handle enemy death.
        Child classes can override for custom death behavior.
        """
        self.is_alive = False
        self.kill()  # Remove from all sprite groups
        
    def heal(self, amount):
        """
        Restore health (for enemies that regenerate).
        """
        self.health = min(self.health + amount, self.max_health)
        
    def move_towards_target(self, target_pos):
        """
        Calculate direction to move towards a target position.
        """
        target_vector = pygame.math.Vector2(target_pos)
        current_pos = pygame.math.Vector2(self.rect.center)
        
        direction = target_vector - current_pos
        
        # Normalize to get direction (avoid division by zero)
        if direction.length() > 0:
            direction = direction.normalize()
            
        return direction
        
    def get_distance_to(self, target_pos):
        """
        Calculate distance to a target position.
        """
        target_vector = pygame.math.Vector2(target_pos)
        current_pos = pygame.math.Vector2(self.rect.center)
        return current_pos.distance_to(target_vector)
        
    def apply_movement(self, dt):
        """
        Apply velocity to position.
        Call this in child class update() after calculating velocity.
        """
        self.rect.x += self.velocity.x * dt * 60  # Scale by 60 for frame-independence
        self.rect.y += self.velocity.y * dt * 60
        
        # Update facing direction
        if self.velocity.x > 0:
            self.facing_right = True
        elif self.velocity.x < 0:
            self.facing_right = False
            
    def clamp_to_level(self):
        """
        Keep enemy within level boundaries.
        Call this after movement in update().
        """
        if self.current_level:
            self.current_level.clamp_sprite(self)
            
    def is_within_level_bounds(self):
        """
        Check if enemy is within level boundaries.
        """
        if self.current_level:
            return self.current_level.is_within_bounds(self)
        return True
        
    def check_collision_with_platforms(self):
        """
        Check and handle collision with platforms.
        Override in child classes for custom platform collision.
        """
        if not self.current_level:
            return False
            
        collisions = pygame.sprite.spritecollide(
            self, 
            self.current_level.platforms, 
            False
        )
        return len(collisions) > 0
        
    def update(self, dt, player_pos=None):
        """
        Update enemy state. MUST be overridden by child classes.
        """
        # Update damage cooldown
        if self.damage_cooldown > 0:
            self.damage_cooldown -= dt
            
        # Child classes should implement their specific update logic
        raise NotImplementedError("Child classes must implement update()")
        
    def draw(self, screen, camera_offset=(0, 0)):
        """
        Draw the enemy (with camera offset for scrolling levels).
        Override if you need custom drawing.
        """
        draw_pos = (
            self.rect.x - camera_offset[0],
            self.rect.y - camera_offset[1]
        )
        screen.blit(self.image, draw_pos)
        
        # Draw health bar (optional - can be toggled)
        if config.SHOW_ENEMY_HEALTH:
            self.draw_health_bar(screen, camera_offset)
            
    def draw_health_bar(self, screen, camera_offset=(0, 0)):
        """
        Draw health bar above enemy.
        """
        bar_width = self.rect.width
        bar_height = 5
        bar_x = self.rect.x - camera_offset[0]
        bar_y = self.rect.y - camera_offset[1] - 10
        
        # Background (red)
        bg_rect = pygame.Rect(bar_x, bar_y, bar_width, bar_height)
        pygame.draw.rect(screen, (255, 0, 0), bg_rect)
        
        # Health (green)
        health_percentage = self.health / self.max_health
        health_width = int(bar_width * health_percentage)
        health_rect = pygame.Rect(bar_x, bar_y, health_width, bar_height)
        pygame.draw.rect(screen, (0, 255, 0), health_rect)
        
        # Border
        pygame.draw.rect(screen, (255, 255, 255), bg_rect, 1)
        
    def __repr__(self):
        """String representation for debugging."""
        return f"{self.__class__.__name__}(pos={self.rect.topleft}, health={self.health}/{self.max_health})"