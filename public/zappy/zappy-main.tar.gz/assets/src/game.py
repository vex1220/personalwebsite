import asyncio
import pygame
import config
from .entities.player import Player
from TitleScreen import TitleScreen
from src.levels.level_menu import run_level_menu


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        pygame.display.set_caption("My Platformer")
        self.clock = pygame.time.Clock()
        self.running = True
        self.dt = 0

        # Player starts at the center
        self.player = Player(self.screen.get_width() / 2, self.screen.get_height() / 2)

    async def run(self):
        while True:
            # Reset display in case a level changed it
            self.screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
            pygame.display.set_caption("Zappy")

            # Title screen
            title = TitleScreen(self.screen, self.clock)
            start_game = await title.run()

            if not start_game:
                continue  # Loop back to title instead of exiting

            # Level selection menu loop
            menu_result = await run_level_menu(self.screen, self.clock)

            # Whether user quit menu or finished a level, loop back to title
            self.screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
            pygame.display.set_caption("Zappy")

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

    def update(self):
        self.player.update()

    def draw(self):
        self.screen.fill("blue")
        self.player.draw(self.screen)
        pygame.display.flip()
