import pygame
import config

class Enemy(pygame.sprite.Sprite):
    """
    Base class for all enemies in Zappy.
    Handles basic movement, health, and collision.
    
    To create a new enemy type:
    1. Inherit from this class
    2. Call super().__init__() with stats
    3. Override update_ai() for custom behavior (optional)
    
    USED IN: All levels (base class)
    """

    def __init__(self, x, y, health, speed, damage):
        super().__init__()
        
        # Visual (placeholder - replace with actual sprites later)
        self.image = pygame.Surface((32, 32))
        self.image.fill((255, 0, 0))  # Red placeholder
        self.rect = self.image.get_rect(center=(x, y))
        
        # Stats
        self.health = health
        self.max_health = health
        self.speed = speed
        self.damage = damage
        
        # Movement
        self.velocity = pygame.math.Vector2(0, 0)
        
        # Combat
        self.damage_cooldown = 0
        self.attack_cooldown = 1.0  # Seconds between attacks
        
        # Level reference
        self.current_level = None

    def set_level(self, level):
        """
        Set reference to the level this enemy is in.
        Called by the level when enemy is added.
        """
        self.current_level = level
    
    def take_damage(self, damage):
        """
        Reduce health by damage amount.
        Returns True if enemy died, False otherwise.
        """
        self.health -= damage
        if self.health <= 0:
            self.kill()  # Remove from all sprite groups
            return True
        return False
    
    def can_attack(self):
        """Check if enemy is ready to attack"""
        return self.damage_cooldown <= 0
    
    def attack(self):
        """
        Call this when enemy attacks player.
        Starts attack cooldown and returns damage dealt.
        """
        self.damage_cooldown = self.attack_cooldown
        return self.damage
        
    def move_towards_target(self, target_pos):
        """
        Calculate normalized direction vector toward target position.
        Returns Vector2 direction (length 1.0 or 0.0).
        """
        target_vector = pygame.math.Vector2(target_pos)
        current_pos = pygame.math.Vector2(self.rect.center)
        
        direction = target_vector - current_pos
        
        # Normalize to get direction (avoid division by zero)
        if direction.length() > 0:
            direction = direction.normalize()
            
        return direction
    
    def update_ai(self, dt, player_pos):
        """
        Override this method in child classes for custom AI behavior.
        Default behavior: chase the player.
        
        Args:
            dt: Delta time in seconds
            player_pos: Tuple (x, y) for player center, or None
        """
        if player_pos:
            direction = self.move_towards_target(player_pos)
            self.velocity = direction * self.speed
        else:
            self.velocity = pygame.math.Vector2(0, 0)
        
    def update(self, dt, player_pos=None):
        """
        Called every frame by sprite group.
        DO NOT override this - override update_ai() instead!
        
        Args:
            dt: Delta time in seconds
            player_pos: Tuple (x, y) for player center
        """
        # Update cooldowns
        if self.damage_cooldown > 0:
            self.damage_cooldown -= dt
        
        # Let child class control AI
        self.update_ai(dt, player_pos)

        # Apply velocity
        self.rect.x += self.velocity.x * dt
        self.rect.y += self.velocity.y * dt

        # Clamp to level boundaries (FIXED)
        if self.current_level:
            self.current_level.clamp_sprite(self)
            
    def draw_health_bar(self, screen, camera_offset=(0, 0)):
        """
        Draw health bar above enemy.
        Only shown when enemy has taken damage.
        """
        # Don't show health bar at full health
        if self.health >= self.max_health:
            return
        
        bar_width = self.rect.width
        bar_height = 5
        bar_x = self.rect.x - camera_offset[0]
        bar_y = self.rect.y - camera_offset[1] - 10
        
        # Background (red)
        bg_rect = pygame.Rect(bar_x, bar_y, bar_width, bar_height)
        pygame.draw.rect(screen, (255, 0, 0), bg_rect)
        
        # Health (green)
        health_percentage = self.health / self.max_health
        health_width = int(bar_width * health_percentage)
        health_rect = pygame.Rect(bar_x, bar_y, health_width, bar_height)
        pygame.draw.rect(screen, (0, 255, 0), health_rect)
        
        # Border (white)
        pygame.draw.rect(screen, (255, 255, 255), bg_rect, 1)
        
    def __repr__(self):
        """String representation for debugging."""
        return f"{self.__class__.__name__}(pos={self.rect.topleft}, health={self.health}/{self.max_health})"