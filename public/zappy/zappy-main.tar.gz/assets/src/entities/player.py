import pygame
from config import PLAYER_SPEED

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, width=15, height=25):
        super().__init__()
        
        # Required sprite attributes
        self.image = pygame.Surface((width, height))
        self.image.fill((255, 0, 0))
        self.rect = self.image.get_rect(topleft=(x, y))
        
        # Movement
        self.vel_x = 0
        self.vel_y = 0
        self.speed = PLAYER_SPEED
        
        # Facing direction (for shooting)
        self.facing_direction = pygame.math.Vector2(1, 0)  # Start facing right
        self.last_move_direction = pygame.math.Vector2(1, 0)
        
        # Level reference
        self.current_level = None

        # Weapon system
        self.current_weapon = None
        self.inventory = []
        
        # Health system
        self.health = 100
        self.max_health = 100
    
    def update(self, dt, keys):
        """Update player - top-down movement"""
        self.handle_input(keys, dt)
        
        # Move
        self.rect.x += self.vel_x
        self.rect.y += self.vel_y
        
        # Update weapon
        if self.current_weapon:
            self.current_weapon.update(dt)
        
        # Clamp to boundaries
        if self.current_level:
            self.current_level.clamp_sprite(self)
    
    def handle_input(self, keys, dt):
        """4-directional top-down movement + arrow key shooting"""
        self.vel_x = 0
        self.vel_y = 0
        
        # Movement with WASD
        move_x = 0
        move_y = 0
        
        if keys[pygame.K_a]:
            move_x = -1
        elif keys[pygame.K_d]:
            move_x = 1
        
        if keys[pygame.K_w]:
            move_y = -1
        elif keys[pygame.K_s]:
            move_y = 1
        
        # Apply movement
        self.vel_x = move_x * self.speed
        self.vel_y = move_y * self.speed
        
        # Update facing direction if moving
        if move_x != 0 or move_y != 0:
            self.facing_direction = pygame.math.Vector2(move_x, move_y).normalize()
            self.last_move_direction = self.facing_direction
        
        # Shooting with ARROW KEYS
        shoot_x = 0
        shoot_y = 0
        
        if keys[pygame.K_LEFT]:
            shoot_x = -1
        elif keys[pygame.K_RIGHT]:
            shoot_x = 1
        
        if keys[pygame.K_UP]:
            shoot_y = -1
        elif keys[pygame.K_DOWN]:
            shoot_y = 1
        
        # Fire weapon in arrow key direction
        if shoot_x != 0 or shoot_y != 0:
            # Calculate target position based on arrow key direction
            shoot_direction = pygame.math.Vector2(shoot_x, shoot_y).normalize()
            shoot_distance = 500  # How far ahead to aim
            
            target_x = self.rect.centerx + shoot_direction.x * shoot_distance
            target_y = self.rect.centery + shoot_direction.y * shoot_distance
            
            self.fire_weapon((target_x, target_y))
    
    def equip_weapon(self, weapon):
        """Equip a weapon"""
        self.current_weapon = weapon
        weapon.set_owner(self)
        
        if self.current_level:
            weapon.set_level(self.current_level)
        
        if weapon not in self.inventory:
            self.inventory.append(weapon)
    
    def fire_weapon(self, target_pos):
        """
        Fire the currently equipped weapon.
        
        Args:
            target_pos: Tuple (x, y) - where to aim
        
        Returns:
            Projectile instance or None
        """
        if self.current_weapon is None:
            return None
        
        projectile = self.current_weapon.fire(target_pos)
        
        # Add projectile to level
        if projectile and self.current_level:
            self.current_level.spawn_projectile(projectile)
        
        return projectile
    
    def take_damage(self, damage):
        """Apply damage to player"""
        self.health = max(0, self.health - damage)
        print(f"Player hit! Health: {self.health}/{self.max_health}")
        if self.health <= 0:
            print("GAME OVER!")
    
    def set_level(self, level):
        """Set the current level reference"""
        self.current_level = level
        
        # Also set level for weapon
        if self.current_weapon:
            self.current_weapon.set_level(level)
    
    def draw(self, screen, camera_offset=(0, 0)):
        """Draw player"""
        draw_rect = self.rect.copy()
        draw_rect.x -= camera_offset[0]
        draw_rect.y -= camera_offset[1]
        screen.blit(self.image, draw_rect)