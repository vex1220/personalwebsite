import pygame

class BaseWeapon(pygame.sprite.Sprite):
    """
    Base class for all weapons in the game.
    Weapons will have infinite ammo by default unless specified.
    """
    def __init__(self, x, y, name="Base Weapon"):
        super().__init__()

        # Visuals (override in child classes)
        self.image = pygame.Surface((20, 10))
        self.image.fill((100, 100, 100))  # Placeholder color
        self.rect = self.image.get_rect(topleft=(x, y))

        # Weapon properties
        self.name = name
        self.damage = 10
        self.fire_rate = 0.5  # Seconds between shots
        self.projectile_speed = 10  # Pixels per second
        self.ammo = -1  # -1 for infinite ammo
        self.max_ammo = -1

        # Cooldown timer
        self.last_shot_time = 0
        self.can_fire = True

        self.owner = None  # Reference to entity that owns the weapon
        self.current_level = None  # Reference to the level the weapon is in

    def set_owner(self, owner):
        """Set the entity that owns this weapon."""
        self.owner = owner

    def set_level(self, level):
        """Set reference to the level this weapon is in."""
        self.current_level = level

    def update(self, dt):
        """Update weapon state (e.g. cooldowns)"""
        if not self.can_fire:
            self.last_shot_time += dt
            if self.last_shot_time >= self.fire_rate:
                self.can_fire = True
                self.last_shot_time = 0
        
        # Update position to follow owner
        if self.owner:
            self.update_position()
    
    def update_position(self):
        """Update weapon position (e.g. to follow player)"""
        if self.owner:
            self.rect.centerx = self.owner.rect.right
            self.rect.centery = self.owner.rect.centery

    def fire(self, target_pos):
        """Fire the weapon if possible"""
        # Check if weapon can fire
        if self.can_fire and (self.ammo != 0):
            # Create projectile
            projectile = self.create_projectile(target_pos)

            if self.ammo > 0:
                self.ammo -= 1
            
            # Start cooldown
            self.can_fire = False
            self.last_shot_time = 0

            return projectile
        
        return None
    
    def create_projectile(self, target_pos=None):
        """Must be implemented in child classes"""
        raise NotImplementedError("create_projectile must be implemented in child classes")


class BasicWeapon(BaseWeapon):
    """
    Simple weapon that fires basic projectiles.
    """
    def __init__(self):
        super().__init__(0, 0, "Basic Blaster")
        
        # Override visuals
        self.image = pygame.Surface((25, 12))
        self.image.fill((150, 150, 200))  # Blue-gray
        
        # Weapon stats
        self.damage = 25
        self.fire_rate = 0.3  # Fast shooting
        self.projectile_speed = 400
    
    def create_projectile(self, target_pos):
        """Create a basic projectile toward target"""
        from src.entities.common.basic_projectile import BasicProjectile
        
        if not self.owner:
            return None
            
        projectile = BasicProjectile(
            self.owner.rect.centerx,
            self.owner.rect.centery,
            target_pos[0],
            target_pos[1],
            speed=self.projectile_speed,
            damage=self.damage
        )
        
        projectile.set_owner(self.owner)
        return projectile