import pygame
import math

class BasicProjectile(pygame.sprite.Sprite):
    def __init__(self, x, y, target_x, target_y, speed=15, damage=10):
        super().__init__()

        # Visual representation (override in child classes)
        self.image = pygame.Surface((8, 8))
        self.image.fill((255, 255, 0))  # Yellow default
        self.rect = self.image.get_rect(center=(x, y))
        
        # Projectile properties
        self.damage = damage
        self.speed = speed
        self.lifetime = 5.0  # Seconds before auto-destroy
        self.age = 0
        
        # Calculate velocity based on target
        self.vel_x, self.vel_y = self.calculate_velocity(x, y, target_x, target_y, speed)
        
        # Owner reference (who shot this)
        self.owner = None
        
        # Level reference
        self.current_level = None

    def calculate_velocity(self, start_x, start_y, target_x, target_y, speed):
        """
        Calculate velocity components to move towards target.
        Returns: Tuple (vel_x, vel_y) in pixels per second
        """

        # Calculate direction vector
        dx = target_x - start_x
        dy = target_y - start_y
        distance = math.sqrt(dx**2 + dy**2)

        # Avoid division by zero
        if distance == 0:
            return speed, 0
        
        # Normalize and scale by speed (pixels per second)
        vel_x = (dx / distance) * speed
        vel_y = (dy / distance) * speed

        return vel_x, vel_y
    
    def set_owner(self, owner):
        """Set the entity that owns this projectile."""
        self.owner = owner

    def set_level(self, level):
        """Set reference to the level this projectile is in."""
        self.current_level = level

    def update(self, dt):
        """
        Update moving position and lifetime.
        
        Args:
            dt: Delta time in seconds (CRITICAL for frame-rate independence)
        """
        # Move - MULTIPLY BY DT FOR SMOOTH MOVEMENT
        self.rect.x += self.vel_x * dt
        self.rect.y += self.vel_y * dt
        
        # Age tracking
        self.age += dt
        if self.age >= self.lifetime:
            self.kill()  # Remove from all sprite groups
            return
        
        # Check if out of bounds
        if self.current_level and not self.current_level.is_within_bounds(self):
            self.kill()

    def on_hit_enemy(self, enemy):
        """Called when projectile hits an enemy. Return True to destroy projectile."""
        return True
    
    def on_hit_obstacle(self, obstacle):
        """Called when projectile hits an obstacle. Return True to destroy projectile."""
        return True


class PiercingProjectile(BasicProjectile):
    """
    Projectile that can hit multiple enemies before being destroyed.
    """
    
    def __init__(self, x, y, target_x, target_y, speed=10, damage=10, max_pierce=3):
        super().__init__(x, y, target_x, target_y, speed, damage)
        
        self.max_pierce = max_pierce
        self.pierce_count = 0
        self.hit_enemies = set()  # Track which enemies we've already hit
    
    def on_hit_enemy(self, enemy):
        """Pierce through enemies up to max_pierce times"""
        # Don't hit the same enemy twice
        if enemy in self.hit_enemies:
            return False
        
        self.hit_enemies.add(enemy)
        self.pierce_count += 1
        
        # Destroy if we've pierced max times
        return self.pierce_count >= self.max_pierce