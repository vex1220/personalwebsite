import pygame
import math
from src.entities.enemy import Enemy
from src.entities.common.basic_projectile import BasicProjectile


class BasicChaser(Enemy):
    """
    Simple enemy that chases the player directly.
    Good for early waves.
    """
    def __init__(self, x, y):
        super().__init__(x, y, health=50, speed=80, damage=10)
        
        # Visual override
        self.image = pygame.Surface((32, 32))
        self.image.fill((200, 50, 50))  # Dark red
        self.rect = self.image.get_rect(center=(x, y))
    
    # Uses default update_ai() from base Enemy class


class FastFlanker(Enemy):
    """
    Fast, low-health enemy that tries to circle the player.
    Creates pressure and forces movement.
    """
    def __init__(self, x, y):
        super().__init__(x, y, health=30, speed=150, damage=5)
        
        # Visual - smaller and orange
        self.image = pygame.Surface((24, 24))
        self.image.fill((255, 150, 0))  # Orange
        self.rect = self.image.get_rect(center=(x, y))
        
        # Flanking behavior
        self.circle_direction = 1  # 1 or -1 for clockwise/counterclockwise
        self.preferred_distance = 150  # Tries to stay at this distance
    
    def update_ai(self, dt, player_pos):
        """Circle around player while maintaining distance"""
        if not player_pos:
            self.velocity = pygame.math.Vector2(0, 0)
            return
        
        # Calculate direction to player
        to_player = self.move_towards_target(player_pos)
        current_pos = pygame.math.Vector2(self.rect.center)
        player_vec = pygame.math.Vector2(player_pos)
        distance = (player_vec - current_pos).length()
        
        # If too close, move away
        if distance < self.preferred_distance - 30:
            self.velocity = -to_player * self.speed
        # If too far, move closer
        elif distance > self.preferred_distance + 30:
            self.velocity = to_player * self.speed
        # At good distance, circle around
        else:
            # Perpendicular vector for circling
            perpendicular = pygame.math.Vector2(-to_player.y, to_player.x) * self.circle_direction
            # Mix of circling and moving toward player
            self.velocity = (perpendicular * 0.7 + to_player * 0.3) * self.speed


class TankBrute(Enemy):
    """
    Slow, tanky enemy with high damage.
    Mini-boss type for later waves.
    """
    def __init__(self, x, y):
        super().__init__(x, y, health=200, speed=40, damage=25)
        
        # Visual - large and dark
        self.image = pygame.Surface((48, 48))
        self.image.fill((100, 20, 20))  # Dark red/brown
        self.rect = self.image.get_rect(center=(x, y))
        
        # Slower attack but hits hard
        self.attack_cooldown = 2.0
    
    # Uses default chasing behavior but moves slow


class RangedShooter(Enemy):
    """
    Stops at medium range and shoots projectiles.
    Forces player to keep moving.
    """
    def __init__(self, x, y):
        super().__init__(x, y, health=40, speed=60, damage=15)
        
        # Visual - blue enemy
        self.image = pygame.Surface((28, 28))
        self.image.fill((50, 100, 200))  # Blue
        self.rect = self.image.get_rect(center=(x, y))
        
        # Shooting behavior
        self.shoot_range = 250  # Stop and shoot at this distance
        self.shoot_cooldown = 0
        self.shoot_interval = 1.5  # Seconds between shots
        self.projectile_speed = 200
        
        # This enemy doesn't deal melee damage
        self.damage = 0  # Only damages through projectiles
    
    def update_ai(self, dt, player_pos):
        """Stop at range and shoot"""
        if not player_pos:
            self.velocity = pygame.math.Vector2(0, 0)
            return
        
        current_pos = pygame.math.Vector2(self.rect.center)
        player_vec = pygame.math.Vector2(player_pos)
        distance = (player_vec - current_pos).length()
        
        # Move toward player if too far
        if distance > self.shoot_range + 50:
            direction = self.move_towards_target(player_pos)
            self.velocity = direction * self.speed
        # Move away if too close
        elif distance < self.shoot_range - 50:
            direction = self.move_towards_target(player_pos)
            self.velocity = -direction * self.speed * 0.5
        # At good range, stop and prepare to shoot
        else:
            self.velocity = pygame.math.Vector2(0, 0)
        
        # Shooting logic
        self.shoot_cooldown -= dt
        if self.shoot_cooldown <= 0 and self.shoot_range - 50 <= distance <= self.shoot_range + 50:
            self.shoot(player_pos)
            self.shoot_cooldown = self.shoot_interval
    
    def shoot(self, target_pos):
        """Create a projectile toward player"""
        if not self.current_level:
            return
        
        # Create projectile
        projectile = BasicProjectile(
            self.rect.centerx,
            self.rect.centery,
            target_pos[0],
            target_pos[1],
            speed=self.projectile_speed,
            damage=15
        )
        
        # Make projectile orange to distinguish from player bullets
        projectile.image.fill((255, 100, 0))
        projectile.set_owner(self)
        projectile.set_level(self.current_level)
        
        # Add to level's enemy projectiles group
        if hasattr(self.current_level, 'enemy_projectiles'):
            self.current_level.enemy_projectiles.add(projectile)


class ExploderEnemy(Enemy):
    """
    Runs at player and explodes on contact or when low health.
    High-risk, high-reward enemy.
    """
    def __init__(self, x, y):
        super().__init__(x, y, health=25, speed=120, damage=30)
        
        # Visual - yellow/orange (warning color)
        self.image = pygame.Surface((28, 28))
        self.image.fill((255, 200, 0))  # Yellow-orange
        self.rect = self.image.get_rect(center=(x, y))
        
        # Explosion properties
        self.explode_radius = 80
        self.explode_damage = 40
        self.explode_on_death = True
        self.is_exploding = False
        
        # Visual warning when low health
        self.flash_timer = 0
        self.flash_interval = 0.1
    
    def update_ai(self, dt, player_pos):
        """Rush toward player, flash when low health"""
        # Flash effect when low health
        if self.health < self.max_health * 0.5:
            self.flash_timer += dt
            if self.flash_timer >= self.flash_interval:
                self.flash_timer = 0
                # Alternate between yellow and red
                if self.image.get_at((0, 0)) == (255, 200, 0, 255):
                    self.image.fill((255, 0, 0))
                else:
                    self.image.fill((255, 200, 0))
        
        # Always rush toward player
        if player_pos:
            direction = self.move_towards_target(player_pos)
            self.velocity = direction * self.speed
        else:
            self.velocity = pygame.math.Vector2(0, 0)
    
    def take_damage(self, damage):
        """Override to trigger explosion on death"""
        self.health -= damage
        if self.health <= 0:
            if self.explode_on_death:
                self.explode()
            self.kill()
            return True
        return False
    
    def explode(self):
        """Deal damage to player if in range"""
        if not self.current_level or self.is_exploding:
            return
        
        self.is_exploding = True
        
        # Check if player is in explosion radius
        player = self.current_level.player
        distance = math.sqrt(
            (player.rect.centerx - self.rect.centerx) ** 2 +
            (player.rect.centery - self.rect.centery) ** 2
        )
        
        if distance <= self.explode_radius:
            # Damage scales with distance (closer = more damage)
            damage_multiplier = 1 - (distance / self.explode_radius)
            actual_damage = int(self.explode_damage * damage_multiplier)
            
            # Apply damage to player (you'll need to implement this)
            if hasattr(player, 'take_damage'):
                player.take_damage(actual_damage)
        
        # Visual effect (optional - can add particle system later)
        # For now, you could add this to a visual effects group
    
    def draw_explosion_radius(self, screen, camera_offset=(0, 0)):
        """Debug visualization of explosion radius"""
        center = (
            self.rect.centerx - camera_offset[0],
            self.rect.centery - camera_offset[1]
        )
        pygame.draw.circle(screen, (255, 100, 0), center, self.explode_radius, 1)


# Helper function to create enemy waves
def create_wave(wave_number, level_width, level_height):
    """
    Generate enemies for a specific wave number.
    
    Args:
        wave_number: Current wave (1, 2, 3, ...)
        level_width: Width of the level
        level_height: Height of the level
    
    Returns:
        List of Enemy instances
    """
    import random
    
    enemies = []
    
    # Helper to spawn at random edge position
    def random_edge_pos():
        edge = random.choice(['top', 'bottom', 'left', 'right'])
        if edge == 'top':
            return (random.randint(50, level_width - 50), 50)
        elif edge == 'bottom':
            return (random.randint(50, level_width - 50), level_height - 50)
        elif edge == 'left':
            return (50, random.randint(50, level_height - 50))
        else:  # right
            return (level_width - 50, random.randint(50, level_height - 50))
    
    # Wave progression
    if wave_number == 1:
        # Easy start - just chasers
        for _ in range(5):
            x, y = random_edge_pos()
            enemies.append(BasicChaser(x, y))
    
    elif wave_number == 2:
        # Introduce flankers
        for _ in range(3):
            x, y = random_edge_pos()
            enemies.append(BasicChaser(x, y))
        for _ in range(2):
            x, y = random_edge_pos()
            enemies.append(FastFlanker(x, y))
    
    elif wave_number == 3:
        # Add first shooter
        for _ in range(4):
            x, y = random_edge_pos()
            enemies.append(BasicChaser(x, y))
        for _ in range(2):
            x, y = random_edge_pos()
            enemies.append(FastFlanker(x, y))
        x, y = random_edge_pos()
        enemies.append(RangedShooter(x, y))
    
    elif wave_number == 4:
        # Introduce exploders
        for _ in range(3):
            x, y = random_edge_pos()
            enemies.append(BasicChaser(x, y))
        for _ in range(2):
            x, y = random_edge_pos()
            enemies.append(ExploderEnemy(x, y))
        x, y = random_edge_pos()
        enemies.append(RangedShooter(x, y))
    
    elif wave_number == 5:
        # First tank appears
        for _ in range(4):
            x, y = random_edge_pos()
            enemies.append(BasicChaser(x, y))
        for _ in range(2):
            x, y = random_edge_pos()
            enemies.append(FastFlanker(x, y))
        x, y = random_edge_pos()
        enemies.append(TankBrute(x, y))
    
    else:
        # Scale up for higher waves
        num_basic = min(wave_number + 2, 10)
        num_flankers = min(wave_number, 5)
        num_shooters = min(wave_number - 2, 3)
        num_exploders = min(wave_number - 3, 4)
        num_tanks = min((wave_number - 4) // 2, 3)
        
        for _ in range(num_basic):
            x, y = random_edge_pos()
            enemies.append(BasicChaser(x, y))
        
        for _ in range(num_flankers):
            x, y = random_edge_pos()
            enemies.append(FastFlanker(x, y))
        
        for _ in range(max(0, num_shooters)):
            x, y = random_edge_pos()
            enemies.append(RangedShooter(x, y))
        
        for _ in range(max(0, num_exploders)):
            x, y = random_edge_pos()
            enemies.append(ExploderEnemy(x, y))
        
        for _ in range(max(0, num_tanks)):
            x, y = random_edge_pos()
            enemies.append(TankBrute(x, y))
    
    return enemies
