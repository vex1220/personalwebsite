# Enemy System Guide - Pygame Best Practices

## Overview
This guide explains the enemy implementation for your Zappy forest survival level, covering design patterns, best practices, and detailed logic explanations.

---

## 📋 Files Created

1. **enemy.py** (corrected base class)
2. **forest_enemies.py** (specialized enemy types)
3. **forest_survival_updated.py** (wave-based level)

---

## 🎯 Core Design Patterns

### 1. Template Method Pattern

**What is it?**
The base `Enemy` class provides a `update()` method that calls `update_ai()`, which child classes can override.

**Why use it?**
- Core logic (cooldowns, movement application, boundary clamping) stays consistent
- Each enemy type only needs to define its unique AI behavior
- Prevents code duplication

**Example:**
```python
# Base Enemy class
def update(self, dt, player_pos=None):
    # Core logic (same for all enemies)
    if self.damage_cooldown > 0:
        self.damage_cooldown -= dt
    
    # AI behavior (unique per enemy)
    self.update_ai(dt, player_pos)  # ← Child overrides this
    
    # Movement application (same for all)
    self.rect.x += self.velocity.x * dt
    self.rect.y += self.velocity.y * dt

# Child class
class FastFlanker(Enemy):
    def update_ai(self, dt, player_pos):
        # Only implement the unique flanking behavior
        # Everything else is handled by parent
```

**Key Rule:** Never override `update()` in child classes—only override `update_ai()`.

---

### 2. Sprite Group Architecture

**Core Concept:**
Pygame sprite groups allow bulk operations on collections of game objects.

**Benefits:**
- Update all enemies with one call: `enemies.update(dt, player_pos)`
- Draw all enemies with one call: `enemies.draw(screen)`
- Collision detection: `pygame.sprite.groupcollide(bullets, enemies, True, False)`

**How it works in your level:**
```python
# In ForestSurvival.__init__()
self.enemies = pygame.sprite.Group()
self.projectiles = pygame.sprite.Group()
self.enemy_projectiles = pygame.sprite.Group()

# In update()
self.enemies.update(dt, self.player.rect.center)
self.projectiles.update(dt)
self.enemy_projectiles.update(dt)

# Collision detection
hits = pygame.sprite.groupcollide(
    self.projectiles,      # Player bullets
    self.enemies,          # Enemies
    True,                  # Remove bullet on hit
    False                  # Don't auto-remove enemy (we handle it manually)
)
```

**Why separate enemy_projectiles from projectiles?**
- Different collision logic (enemy bullets hit player, player bullets hit enemies)
- Different visual effects
- Easier to implement friendly fire or shields later

---

## 🧠 Enemy AI Behaviors Explained

### 1. Basic Chaser (Simple Pursuit)

**Logic:**
```python
def update_ai(self, dt, player_pos):
    if player_pos:
        direction = self.move_towards_target(player_pos)
        self.velocity = direction * self.speed
```

**How it works:**
1. Calculate vector from enemy to player: `player_pos - enemy_pos`
2. Normalize vector to length 1.0: `direction.normalize()`
3. Multiply by speed: `direction * speed`

**Math breakdown:**
```
Enemy at (100, 100)
Player at (300, 200)

Vector to player: (300-100, 200-100) = (200, 100)
Distance: sqrt(200² + 100²) = 223.6
Normalized: (200/223.6, 100/223.6) = (0.894, 0.447)
Velocity at speed 80: (0.894*80, 0.447*80) = (71.5, 35.8) px/s
```

---

### 2. Fast Flanker (Orbital Movement)

**Strategy:** Maintain distance while circling the player.

**Logic:**
```python
# Calculate distance to player
distance = (player_vec - current_pos).length()

# Three behaviors based on distance:
if distance < preferred_distance - 30:
    # Too close → move away
    self.velocity = -to_player * self.speed
elif distance > preferred_distance + 30:
    # Too far → move closer
    self.velocity = to_player * self.speed
else:
    # Perfect distance → circle around
    perpendicular = pygame.math.Vector2(-to_player.y, to_player.x)
    self.velocity = (perpendicular * 0.7 + to_player * 0.3) * self.speed
```

**Perpendicular vector math:**
```
If direction to player is (0.8, 0.6):
Perpendicular clockwise: (-0.6, 0.8)
Perpendicular counter-clockwise: (0.6, -0.8)

This creates circular motion around the player!
```

**Why mix perpendicular + toward player (0.7 + 0.3)?**
- Pure perpendicular = perfect circle (predictable, easy to dodge)
- Adding small toward component = spiral inward (more aggressive)
- Creates more dynamic, unpredictable movement

---

### 3. Ranged Shooter (Kiting Behavior)

**Strategy:** Maintain optimal shooting distance.

**Logic:**
```python
if distance > self.shoot_range + 50:
    # Too far → move closer
    self.velocity = direction * self.speed
elif distance < self.shoot_range - 50:
    # Too close → backpedal
    self.velocity = -direction * self.speed * 0.5  # Slower retreat
else:
    # Good range → stop and shoot
    self.velocity = pygame.math.Vector2(0, 0)
    
    # Shooting cooldown
    if self.shoot_cooldown <= 0:
        self.shoot(player_pos)
```

**Why slower retreat speed (0.5)?**
- Makes enemy vulnerable when player closes in
- Rewards aggressive play
- Prevents infinite kiting

**Shooting implementation:**
```python
def shoot(self, target_pos):
    projectile = BasicProjectile(
        self.rect.centerx,
        self.rect.centery,
        target_pos[0],
        target_pos[1],
        speed=200,
        damage=15
    )
    
    # Change color to distinguish from player bullets
    projectile.image.fill((255, 100, 0))  # Orange
    
    # Add to enemy projectiles group
    self.current_level.enemy_projectiles.add(projectile)
```

---

### 4. Exploder Enemy (Kamikaze)

**Strategy:** Rush player and explode on death or contact.

**Key features:**
- Visual warning (flashing) when low health
- Explosion radius damage with falloff
- High risk for player, high reward for killing it early

**Flashing logic:**
```python
if self.health < self.max_health * 0.5:
    self.flash_timer += dt
    if self.flash_timer >= self.flash_interval:
        # Toggle color between yellow and red
        if self.image.get_at((0, 0)) == (255, 200, 0, 255):
            self.image.fill((255, 0, 0))  # Red = danger!
        else:
            self.image.fill((255, 200, 0))  # Yellow = warning
```

**Explosion damage falloff:**
```python
# Calculate distance to player
distance = sqrt((player_x - enemy_x)² + (player_y - enemy_y)²)

if distance <= explode_radius:
    # Damage decreases with distance
    damage_multiplier = 1 - (distance / radius)
    actual_damage = base_damage * damage_multiplier
    
    # Example:
    # At 0 distance: 1 - (0/80) = 1.0 → full damage (40)
    # At 40 distance: 1 - (40/80) = 0.5 → half damage (20)
    # At 80 distance: 1 - (80/80) = 0 → no damage
```

---

## 🎮 Wave System Explained

### Wave Progression Design

**Philosophy:** Gradual difficulty increase with enemy variety.

**Wave 1:** Tutorial wave
```python
# 5 Basic Chasers only
# Teaches player: movement, shooting, kiting
```

**Wave 2:** Introduce movement complexity
```python
# 3 Chasers + 2 Flankers
# Teaches player: can't stand still, need to prioritize targets
```

**Wave 3:** Ranged threat
```python
# 4 Chasers + 2 Flankers + 1 Shooter
# Teaches player: must dodge projectiles while kiting melee
```

**Waves 4-5:** Multi-threat management
```python
# Mix of all enemy types
# Teaches player: target priority, risk assessment
```

**Wave 6+:** Scaling difficulty
```python
# Formula-based scaling:
num_basic = min(wave_number + 2, 10)
num_flankers = min(wave_number, 5)
num_shooters = min(wave_number - 2, 3)
```

**Why cap enemy counts?**
- Too many enemies = performance issues
- Too many = overwhelming, not fun
- Quality > quantity: Better AI is more engaging than spam

---

### Wave State Machine

```python
# State 1: Wave Active
self.wave_active = True
self.wave_complete = False
# Enemies spawned, fighting happens

# State 2: Wave Complete
if len(self.enemies) == 0:
    self.wave_active = False
    self.wave_complete = True
    self.wave_timer = 0  # Start countdown

# State 3: Inter-wave Delay
if self.wave_complete:
    self.wave_timer += dt
    if self.wave_timer >= self.wave_start_delay:
        # Start next wave
        self.start_wave(self.current_wave + 1)
```

---

## 🎯 Collision Detection Deep Dive

### Player Projectiles vs Enemies

```python
hits = pygame.sprite.groupcollide(
    self.projectiles,      # Group A: player bullets
    self.enemies,          # Group B: enemies
    True,                  # dokill1: Remove bullets on hit
    False                  # dokill2: Don't remove enemies (manual handling)
)

# Returns: {projectile: [enemy1, enemy2, ...]}
for projectile, enemy_list in hits.items():
    for enemy in enemy_list:
        enemy.take_damage(projectile.damage)
        # enemy.kill() is called inside take_damage() if health <= 0
```

**Why `dokill2=False`?**
- We want to call `enemy.take_damage()` for proper death handling
- Allows death animations, explosion effects, score tracking
- Direct `kill()` would skip all that logic

---

### Enemy Projectiles vs Player

```python
player_hit = pygame.sprite.spritecollide(
    self.player,              # Single sprite
    self.enemy_projectiles,   # Group
    True                      # dokill: Remove projectile on hit
)

# Returns: [projectile1, projectile2, ...]
for projectile in player_hit:
    self.player.take_damage(projectile.damage)
```

**Single sprite vs group:**
- Use `spritecollide()` when checking one sprite against a group
- Use `groupcollide()` when checking two groups against each other

---

### Melee Damage (Enemy Touch)

```python
enemy_collisions = pygame.sprite.spritecollide(
    self.player,
    self.enemies,
    False  # Don't remove enemy (can attack multiple times)
)

for enemy in enemy_collisions:
    if enemy.can_attack():  # Check cooldown
        damage = enemy.attack()  # Starts cooldown, returns damage
        self.player.take_damage(damage)
```

**Why check `can_attack()`?**
- Prevents damage every single frame
- With cooldown: 1 hit per second
- Without cooldown: 60 hits per second at 60 FPS!

---

## 🚀 Performance Considerations

### Optimization Tips

1. **Limit enemy count per wave**
```python
# Bad: Unlimited scaling
num_enemies = wave_number * 10  # Wave 20 = 200 enemies! (lag)

# Good: Capped scaling
num_enemies = min(wave_number * 2, 50)  # Never more than 50
```

2. **Cull off-screen enemies (future improvement)**
```python
def is_on_screen(self, sprite, camera_offset):
    screen_rect = pygame.Rect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)
    sprite_screen_rect = sprite.rect.copy()
    sprite_screen_rect.x -= camera_offset[0]
    sprite_screen_rect.y -= camera_offset[1]
    return screen_rect.colliderect(sprite_screen_rect)

# In update()
for enemy in self.enemies:
    if self.is_on_screen(enemy, (self.camera_x, self.camera_y)):
        enemy.update(dt, player_pos)  # Only update visible enemies
```

3. **Use sprite groups efficiently**
```python
# Bad: Iterate and check manually
for enemy in self.enemies:
    if enemy.rect.colliderect(self.player.rect):
        # collision logic

# Good: Use built-in collision detection (optimized in C)
hits = pygame.sprite.spritecollide(self.player, self.enemies, False)
```

---

## 🐛 Common Mistakes to Avoid

### 1. Forgetting `set_level()`
```python
# Bad: Enemy doesn't know level boundaries
enemy = BasicChaser(100, 100)
self.enemies.add(enemy)
# Enemy will crash when trying to clamp!

# Good: Always set level reference
enemy = BasicChaser(100, 100)
enemy.set_level(self)  # ← Critical!
self.enemies.add(enemy)
```

### 2. Not calling `super().__init__()`
```python
# Bad: Missing parent initialization
class MyEnemy(Enemy):
    def __init__(self, x, y):
        # Forgot super().__init__()
        self.my_custom_attr = 10
        # Missing: image, rect, health, speed, etc.

# Good: Always call parent constructor
class MyEnemy(Enemy):
    def __init__(self, x, y):
        super().__init__(x, y, health=100, speed=80, damage=15)
        self.my_custom_attr = 10
```

### 3. Overriding `update()` instead of `update_ai()`
```python
# Bad: Breaks core functionality
class MyEnemy(Enemy):
    def update(self, dt, player_pos):
        # Custom AI here
        # Forgot to call super().update()
        # Now cooldowns don't work, movement broken!

# Good: Override update_ai()
class MyEnemy(Enemy):
    def update_ai(self, dt, player_pos):
        # Custom AI here
        # Core logic still runs from parent update()
```

### 4. Applying velocity twice
```python
# Bad: Movement happens twice!
class MyEnemy(Enemy):
    def update_ai(self, dt, player_pos):
        direction = self.move_towards_target(player_pos)
        self.velocity = direction * self.speed
        
        # Don't do this! Parent update() already does it!
        self.rect.x += self.velocity.x * dt
        self.rect.y += self.velocity.y * dt

# Good: Just set velocity
class MyEnemy(Enemy):
    def update_ai(self, dt, player_pos):
        direction = self.move_towards_target(player_pos)
        self.velocity = direction * self.speed
        # Parent update() will apply velocity
```

---

## 📊 Testing Checklist

Before you integrate into your main game:

- [ ] Enemies spawn at correct positions
- [ ] Enemies chase player correctly
- [ ] Player projectiles damage enemies
- [ ] Enemy projectiles damage player
- [ ] Melee damage has cooldown (not every frame)
- [ ] Enemies stay within level boundaries
- [ ] Health bars display correctly
- [ ] Enemies die at 0 health
- [ ] Wave counter displays correctly
- [ ] Next wave starts after delay
- [ ] Level completes after max waves
- [ ] Camera follows player smoothly
- [ ] No performance lag with max enemies

---

## 🎓 Key Takeaways

1. **Template Method Pattern** = Core logic in parent, custom behavior in child
2. **Sprite Groups** = Bulk operations and efficient collision detection
3. **Delta Time** = Multiply movement by `dt` for frame-rate independence
4. **Level References** = Entities need to know their level for boundaries
5. **Separation of Concerns** = Each method does one thing well
6. **Progressive Difficulty** = Start easy, add complexity gradually
7. **Performance Matters** = Cap enemy counts, optimize collision checks

---

## 🔧 Next Steps for You

1. **Add player health system:**
```python
class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.health = 100
        self.max_health = 100
    
    def take_damage(self, damage):
        self.health -= damage
        if self.health <= 0:
            # Game over logic
            pass
```

2. **Add score tracking:**
```python
class ForestSurvival(BaseLevel):
    def __init__(self, player):
        super().__init__(player)
        self.score = 0
        self.points_per_kill = {
            BasicChaser: 10,
            FastFlanker: 15,
            RangedShooter: 20,
            TankBrute: 50,
            ExploderEnemy: 25
        }
```

3. **Add particle effects for explosions/hits**

4. **Add sound effects**

5. **Polish UI and feedback**

---

## 💡 Advanced Improvements (Future)

- **Enemy pathfinding** around obstacles
- **Formation movement** (enemies move in squads)
- **Boss enemies** with multiple phases
- **Enemy abilities** (shields, teleportation, summoning)
- **Dynamic difficulty** based on player performance
- **Power-ups** dropped by enemies

---

Good luck with your forest survival level! 🎮🌲
