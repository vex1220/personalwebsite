# Zappy

A 2D action game featuring multiple gameplay modes including survival, platforming, and arcade-style challenges. Players control characters across different environments with various mechanics and objectives.

---

## Features
- Multiple distinct game levels with different mechanics
- Survival mode with enemy waves and difficulty scaling
- Boss arena with platforming combat mechanics
- Arcade-style mini-games including Doodle Jump and Flappy Bird variants
- Health and damage systems with visual feedback
- Weapon systems and projectile combat
- Game over screens with restart functionality
- Comprehensive level selection menu
- ESC key functionality for seamless navigation between levels

---

## Project Structure
> **Note:** Some files and folders listed below are planned for future development and may not exist yet. This structure serves as a roadmap for the full project.

```
Zappy/
├── main.py                 # Entry point - runs the game
├── main_test.py            # Test runner for development
├── requirements.txt        # Dependencies (pygame, etc.)
├── config.py               # Game constants (screen size, colors, speeds)
├── TitleScreen.py          # Initial title screen implementation
│
├── src/                    # Source code
│   ├── __init__.py
│   ├── game.py             # Main game class and game loop
│   │
│   ├── entities/           # Game objects
│   │   ├── __init__.py
│   │   ├── player.py       # Player character with health and combat
│   │   ├── enemy.py        # Base enemy class with AI and damage systems
│   │   ├── base_weapon.py  # Weapon system with projectiles
│   │   └── common/         # Shared entity components
│   │       ├── basic_projectile.py # Projectile physics and collision
│   │       ├── forest_enemies.py   # Specialized enemy types for survival mode
│   │       └── __init__.py
│   │
│   ├── levels/             # Level implementations
│   │   ├── __init__.py
│   │   ├── base_level.py   # Base level class with common functionality
│   │   ├── level_menu.py   # Main level selection and navigation
│   │   ├── forest_survival.py # Top-down survival mode with wave spawning
│   │   │
│   │   ├── boss_level/     # Platformer boss arena (self-contained)
│   │   │   ├── __init__.py
│   │   │   ├── level.py    # Boss arena main level logic
│   │   │   ├── player.py   # Platformer player with jump mechanics
│   │   │   ├── enemy.py    # Boss enemy base class
│   │   │   ├── enemies.py  # Boss-specific enemy implementations
│   │   │   ├── platform.py # Platform objects for boss arena
│   │   │   └── final_boss.py # Advanced boss implementation
│   │   │
│   │   ├── doodle_jump/    # Vertical scrolling mini-game
│   │   │   ├── platform.py # Jumping platform mechanics
│   │   │   ├── player.py   # Doodle jump player physics
│   │   │   ├── scene.py    # Game scene management
│   │   │   └── run.py      # Doodle jump main loop
│   │   │
│   │   ├── Flappybird/     # Side-scrolling obstacle course
│   │   │   ├── flappybird.py # Flappy bird game implementation
│   │   │   └── flappybird_images/ # Flappy bird visual assets
│   │   │
│   │   └── flappybird_images/ # Additional flappy bird assets
│   │       ├── FB_background.png
│   │       ├── flappybirdPipe_bottom.jpg
│   │       ├── flappybirdPipe_bottom.png
│   │       └── flappybirdPipe_top.png
│
├── assets/                 # Game assets
│   └── images/             # Visual assets for game objects
│
├── docs/                   # Documentation
│   ├── README.md           # This file
│   ├── ENEMY_SPAWNING_GUIDE.md  # Enemy spawn system documentation
│   ├── ENEMY_SYSTEM_GUIDE.md    # Enemy behavior and AI guide
│   └── ESC_KEY_FUNCTIONALITY.md # Navigation system documentation
│
└── __pycache__/            # Python bytecode cache
```

---

## Setup & Installation
1. Clone the repository:
   ```sh
   git clone https://github.com/The-Duz/Zappy.git
   cd Zappy
   ```
2. Create a virtual environment (recommended):
   ```sh
   python -m venv .venv
   # On Windows:
   .venv\Scripts\activate
   # On Unix/Linux/macOS:
   source .venv/bin/activate
   ```
3. Install dependencies:
   ```sh
   pip install -r requirements.txt
   ```

---

## Running the Game
```sh
python main.py
```

## Game Levels

### Level Selection Menu
After the title screen, access the main level selection menu with these options:

1. **Forest Survival** — Top-down survival mode with wave-based enemy spawning, health system, and progressive difficulty scaling
2. **Boss Arena** — Platform-based boss battle with jump mechanics, enemy stomping, and collision-based combat
3. **Doodle Jump** — Vertical scrolling platformer with procedural platform generation
4. **Flappy Zappy** — Side-scrolling obstacle avoidance game with pipe navigation
5. **Quit** — Exit the application

### Controls

**Menu Navigation:**
- Up/Down arrows or W/S: Navigate menu options
- Enter or Space: Select highlighted option
- Esc or Q: Exit to previous menu or quit application

**In-Game Controls:**
- **Forest Survival**: WASD movement, mouse click for weapon firing, ESC to return to menu
- **Boss Arena**: A/D for horizontal movement, W/Space for jumping, mouse click for barking attack, ESC to return to menu
- **Doodle Jump**: A/D for horizontal movement, automatic jumping on platform contact, ESC to return to menu
- **Flappy Zappy**: Space or mouse click for upward thrust, ESC to return to menu

**Universal Navigation:**
- ESC key returns to the level selection menu from any active level

### Game Features by Level

**Forest Survival:**
- Real-time enemy wave spawning with increasing difficulty
- Player health system with visual feedback
- Multiple enemy types with different behaviors and attack patterns
- Weapon system with projectile physics
- Game over screen with restart functionality
- Statistics tracking (survival time, enemies defeated)

**Boss Arena:**
- Platformer physics with jumping and collision detection
- Enemy damage system with "jump on top" mechanics
- Player invulnerability frames after taking damage
- Visual health display and damage feedback
- Platform-based level design with multiple elevation levels

**Doodle Jump:**
- Infinite vertical scrolling gameplay
- Platform collision and jumping physics
- Score tracking and progression system

**Flappy Zappy:**
- Physics-based flight mechanics
- Obstacle collision detection
- Side-scrolling level progression

