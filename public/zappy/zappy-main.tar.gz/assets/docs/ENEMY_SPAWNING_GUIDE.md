# Enemy Spawning System - Forest Survival

The Forest Survival level now features a dynamic enemy spawning system with weighted random selection and difficulty scaling.

## How It Works

### Spawn Timing (Enhanced)
- **Base Spawn Interval**: 2.5 seconds between enemy spawns (faster)
- **Difficulty Scaling**: After 20 seconds, spawn rate increases aggressively
  - 0.04s reduction per spawn (20-60s), then 0.08s reduction (60s+)
- **Minimum Interval**: 1.0 seconds (more intense late game)
- **Max Enemies**: 25 enemies on screen at once (increased capacity)
- **Multi-Spawning**: 1-5 enemies can spawn per spawn event

### Enemy Types & Spawn Weights (Enhanced)

| Enemy Type | Spawn Weight | Available After | Difficulty |
|------------|--------------|----------------|------------|
| **BasicChaser** | 80 (Common) | 0s | Easy |
| **FastFlanker** | 70 (Common) | 20s ⚡ | Medium |
| **RangedShooter** | 50 (Frequent) | 40s ⚡ | Medium-Hard |
| **ExploderEnemy** | 35 (Regular) | 60s ⚡ | Hard |
| **TankBrute** | 20 (Uncommon) | 90s ⚡ | Very Hard |

**⚡ = Earlier unlock times and higher spawn rates for special enemies**

### Weighted Random Selection

The system uses weighted probabilities:
- Higher weight = more likely to spawn
- Tougher enemies have lower weights
- Only available enemies (based on time) are considered
- Random roll determines which enemy spawns

### Spawn Locations

Enemies spawn at random edge positions:
- **Buffer Zone**: 100 pixels outside camera view
- **Edge Selection**: Random choice of top/bottom/left/right
- **Smart Positioning**: Spawns relative to camera, not absolute map position

## Combat System

### Player Combat
- **Weapon**: Auto-equipped BasicWeapon on level start
- **Projectile Damage**: 25 per shot
- **Fire Rate**: 0.3 seconds between shots
- **Controls**: Arrow keys to aim and shoot

### Enemy Combat
- **Melee Damage**: Contact damage with attack cooldowns
- **Ranged Attacks**: Some enemies fire projectiles (orange colored)
- **Health System**: Enemies show health bars when damaged
- **Death**: Enemies drop when health reaches 0

### Collision Detection
- Player projectiles vs enemies
- Enemy projectiles vs player
- Enemy melee vs player

## Enhanced UI Information

The level now displays:
- **Enemy Count**: Current/max enemies (e.g., "15/25")
- **Time Survived**: Total time in level
- **Next Spawn**: Countdown + spawn count (e.g., "2.1s (3x)")
- **Spawn Rate**: Current spawn interval speed
- **Enemy Breakdown**: Count of each enemy type on right side
- **Player Health**: If health system is implemented

## Multi-Spawn System

### Progressive Spawn Count
- **0-30s**: 1-2 enemies per spawn
- **30-90s**: 2-3 enemies per spawn  
- **90-150s**: 3-4 enemies per spawn
- **150s+**: 4-5 enemies per spawn

### Random Variation
- Base spawn count + 0-2 random bonus enemies
- Creates unpredictable waves for dynamic challenge

## Customization

### Adding New Enemy Types
1. Create enemy class in `forest_enemies.py`
2. Add to `enemy_spawn_table` in `ForestSurvival.__init__()`
3. Set spawn weight and minimum time

### Adjusting Difficulty
- **Spawn Rate**: Modify `spawn_interval` and scaling in `update_enemy_spawning()`
- **Enemy Weights**: Adjust values in `enemy_spawn_table`
- **Max Enemies**: Change `max_enemies` limit
- **Unlock Times**: Modify minimum time requirements

### Balancing Tips
- **Early Game**: Keep BasicChaser weight high for consistent early enemies
- **Mid Game**: FastFlanker provides movement pressure
- **Late Game**: Mix of all types creates varied challenges
- **Boss Enemies**: TankBrute should remain rare but impactful

## Future Enhancements

Possible improvements:
- **Wave System**: Discrete waves instead of continuous spawning
- **Elite Enemies**: Rare, powerful variants with special abilities
- **Spawn Patterns**: Coordinated group spawns
- **Player Progression**: Weapon upgrades, health increases
- **Boss Encounters**: Special high-health enemies with unique mechanics